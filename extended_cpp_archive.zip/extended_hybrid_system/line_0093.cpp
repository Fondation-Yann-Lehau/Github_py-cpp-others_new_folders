        case OperationType::NOR:  return "NOR (⊽)";
