                throw std::invalid_argument("Opération non supportée");
