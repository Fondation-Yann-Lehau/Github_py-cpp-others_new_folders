     * Exécute un cycle complet de navigation.
