        stats["total_execution_time_ms"] = totalExecutionTimeMs;
