    std::optional<bool> observedState;
