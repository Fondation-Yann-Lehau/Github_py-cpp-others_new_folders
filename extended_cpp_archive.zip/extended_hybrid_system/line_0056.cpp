    NOT,    // Négation
