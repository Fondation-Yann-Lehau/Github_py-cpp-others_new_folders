        stats["total_operations"] = static_cast<double>(totalOps);
