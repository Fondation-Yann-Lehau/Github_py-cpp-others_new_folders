        std::cout << "  [" << operationToString(op) << "] Résultat: " 
