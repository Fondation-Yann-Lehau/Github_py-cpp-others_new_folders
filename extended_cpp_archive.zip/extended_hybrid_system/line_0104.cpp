        case NavigationDecision::FORWARD:    return "FORWARD";
