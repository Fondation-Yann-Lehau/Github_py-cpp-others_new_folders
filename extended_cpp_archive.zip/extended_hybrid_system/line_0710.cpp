        : maxRetries(retries), retryDelayMs(delayMs) {}
