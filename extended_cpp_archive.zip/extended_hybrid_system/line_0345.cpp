    std::map<OperationType, int> operationCounts;
