        : context(ctx), potentialState(potential), 
