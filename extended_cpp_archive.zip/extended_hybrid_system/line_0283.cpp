     * Affiche la description du paradigme.
