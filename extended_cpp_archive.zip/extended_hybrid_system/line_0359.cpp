                return std::all_of(inputs.begin(), inputs.end(), 
