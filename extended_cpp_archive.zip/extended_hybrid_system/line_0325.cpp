        summary["ones"] = static_cast<int>(std::count_if(observations.begin(), 
