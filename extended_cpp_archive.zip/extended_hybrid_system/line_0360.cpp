                    [](bool b) { return b; });
