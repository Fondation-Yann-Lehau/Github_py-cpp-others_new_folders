     * Affiche un rapport complet du système.
