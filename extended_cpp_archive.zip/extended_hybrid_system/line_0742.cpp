        return total > 0 ? static_cast<double>(errorCount) / total : 0;
