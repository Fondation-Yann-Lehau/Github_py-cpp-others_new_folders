        result.collapsedResult = collapsedResult;
