                      << data[i] << std::endl;
