                std::cout << "[RÉSILIENCE] Tentative " << (attempt + 1) 
