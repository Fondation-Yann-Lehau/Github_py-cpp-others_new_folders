                      << transformed[i] << " ";
