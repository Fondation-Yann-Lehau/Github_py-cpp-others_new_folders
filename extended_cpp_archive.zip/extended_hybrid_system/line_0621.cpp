     * Retourne les statistiques des lectures.
