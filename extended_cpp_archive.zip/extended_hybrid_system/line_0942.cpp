        std::cout << "Données d'entrée: " << testData.substr(0, 40) << "..." << std::endl;
