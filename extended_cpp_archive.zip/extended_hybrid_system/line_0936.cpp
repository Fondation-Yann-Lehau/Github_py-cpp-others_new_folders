        std::cout << "TEST 2: TRANSFORMATION DE DONNÉES" << std::endl;
