            std::cout << "[ 0 ] (ANNULÉ)" << std::endl;
