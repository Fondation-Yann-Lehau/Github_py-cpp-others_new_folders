class LogicProcessor {
