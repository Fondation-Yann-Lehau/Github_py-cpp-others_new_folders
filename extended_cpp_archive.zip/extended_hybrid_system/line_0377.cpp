            case OperationType::NOR: {
