 * Système de navigation basé sur la logique symbolique.
