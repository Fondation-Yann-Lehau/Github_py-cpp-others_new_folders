        if (!enabled || data.empty()) return;
