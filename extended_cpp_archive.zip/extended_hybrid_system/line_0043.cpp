enum class BinaryState {
