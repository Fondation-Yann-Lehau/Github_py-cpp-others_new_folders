        logic = std::make_shared<LogicProcessor>(bridge, viz);
