        std::map<std::string, double> stats;
