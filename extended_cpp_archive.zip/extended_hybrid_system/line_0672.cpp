     * Définit l'état de l'actionneur.
