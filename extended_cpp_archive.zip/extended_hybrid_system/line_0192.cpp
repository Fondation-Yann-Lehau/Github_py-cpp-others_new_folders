        // Phase 1: Onde
