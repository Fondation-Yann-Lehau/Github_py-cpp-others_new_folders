        // Mise à jour des statistiques
