 * Développe les concepts de transition cycloidale, conjonction/annulation,
