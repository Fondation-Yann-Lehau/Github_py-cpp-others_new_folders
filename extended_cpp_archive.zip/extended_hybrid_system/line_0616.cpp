        for (double r : readings) sum += r;
