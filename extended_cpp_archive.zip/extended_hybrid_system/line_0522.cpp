class AbstractFactorQuantifier {
