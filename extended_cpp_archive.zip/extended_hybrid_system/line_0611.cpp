     * Retourne la moyenne des lectures.
