            case OperationType::XOR: {
