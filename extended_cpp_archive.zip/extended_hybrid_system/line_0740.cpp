    double getErrorRate() const {
