        bool finalState = (state == BinaryState::ONE);
