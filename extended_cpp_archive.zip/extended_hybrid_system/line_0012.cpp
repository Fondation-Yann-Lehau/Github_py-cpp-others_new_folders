 * Environ 1000 lignes de code fonctionnel.
