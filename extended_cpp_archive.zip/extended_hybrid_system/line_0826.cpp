        navigationLog.push_back(decision);
