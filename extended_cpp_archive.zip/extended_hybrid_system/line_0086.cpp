std::string operationToString(OperationType op) {
