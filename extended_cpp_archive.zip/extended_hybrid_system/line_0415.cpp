        // Calcul du temps d'exécution
