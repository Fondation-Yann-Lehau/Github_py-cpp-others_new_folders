        std::cout << "  Temps d'exécution total: " 
