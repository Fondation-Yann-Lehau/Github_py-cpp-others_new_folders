        bool rightClear = readings.at("right") >= obstacleThreshold;
