    explicit AbstractFactorQuantifier(double coeff = 0.873)
