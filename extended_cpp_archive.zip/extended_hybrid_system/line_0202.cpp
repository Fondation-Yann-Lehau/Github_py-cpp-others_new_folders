        std::cout << "(•) (TRANSITION) ";
