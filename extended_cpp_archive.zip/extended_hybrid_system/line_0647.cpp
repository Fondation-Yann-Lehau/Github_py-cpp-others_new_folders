        return stats;
