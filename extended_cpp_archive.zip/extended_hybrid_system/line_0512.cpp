    int getTransformationsCount() const { return transformationsCount; }
