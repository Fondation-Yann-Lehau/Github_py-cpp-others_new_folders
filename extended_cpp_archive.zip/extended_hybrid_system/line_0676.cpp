        isActive = currentState > 0;
