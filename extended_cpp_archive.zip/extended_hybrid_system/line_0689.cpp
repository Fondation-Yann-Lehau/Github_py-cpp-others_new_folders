        return stateHistory;
