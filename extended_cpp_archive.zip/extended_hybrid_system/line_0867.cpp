    size_t getNavigationLogSize() const { return navigationLog.size(); }
