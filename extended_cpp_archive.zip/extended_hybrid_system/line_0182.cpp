     * Visualise l'effondrement d'un état quantique.
