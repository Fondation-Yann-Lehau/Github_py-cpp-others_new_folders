        double maxVal = *std::max_element(data.begin(), data.end(),
