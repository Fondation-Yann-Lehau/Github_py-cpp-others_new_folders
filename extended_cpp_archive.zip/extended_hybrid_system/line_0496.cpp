        result.reserve(data.size());
