     * Visualise une transition d'état.
