        double avg = stats["avg"];
