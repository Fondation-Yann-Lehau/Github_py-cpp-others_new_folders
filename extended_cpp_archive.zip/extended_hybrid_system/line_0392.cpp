                   std::shared_ptr<VisualizationEngine> v = nullptr)
