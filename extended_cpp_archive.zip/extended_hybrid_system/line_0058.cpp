    NOR,    // Non-disjonction
