        : securityCoefficient(coeff) {
