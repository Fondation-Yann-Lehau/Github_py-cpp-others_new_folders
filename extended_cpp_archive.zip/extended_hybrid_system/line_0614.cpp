        if (readings.empty()) return 0;
