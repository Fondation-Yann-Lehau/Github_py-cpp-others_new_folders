    XNOR    // Équivalence
