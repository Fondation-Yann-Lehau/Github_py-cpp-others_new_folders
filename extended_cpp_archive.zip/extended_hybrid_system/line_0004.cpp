 * Extension complète du système hybride quantique-binaire en C++.
