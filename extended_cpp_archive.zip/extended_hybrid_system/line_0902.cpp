        quantifier = std::make_unique<AbstractFactorQuantifier>();
