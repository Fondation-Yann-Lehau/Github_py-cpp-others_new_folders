        viz->visualizeOperation(operation, rawResult);
