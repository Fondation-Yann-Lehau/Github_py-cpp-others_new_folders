    double securityCoefficient;
