            case OperationType::XNOR: {
