     * Calcule le résultat brut d'une opération.
