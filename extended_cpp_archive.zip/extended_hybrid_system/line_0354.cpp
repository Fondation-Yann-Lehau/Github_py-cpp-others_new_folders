            throw std::invalid_argument("Aucune entrée fournie");
