        // Statistiques du pont quantique
