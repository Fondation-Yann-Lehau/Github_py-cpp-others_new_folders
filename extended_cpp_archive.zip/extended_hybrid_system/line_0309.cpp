        visualizeTransition(potential);
