    std::map<std::string, int> getObservationsSummary() const {
