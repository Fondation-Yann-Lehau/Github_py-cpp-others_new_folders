        std::cout << "[NAVIGATION] Exécution: " << decisionToString(decision) 
