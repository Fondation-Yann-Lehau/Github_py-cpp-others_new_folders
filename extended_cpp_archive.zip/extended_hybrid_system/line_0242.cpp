        size_t limit = std::min(data.size(), static_cast<size_t>(10));
