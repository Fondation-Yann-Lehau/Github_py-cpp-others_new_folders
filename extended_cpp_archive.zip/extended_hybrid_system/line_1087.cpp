    QuantumSymbolic::UnifiedExtendedSystem system(100);
