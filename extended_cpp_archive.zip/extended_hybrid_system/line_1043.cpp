        std::cout << "\n[Résilience]" << std::endl;
