    std::map<std::string, double> readAllSensors() {
