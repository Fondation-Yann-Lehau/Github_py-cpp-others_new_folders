        std::cout << paradigmDescription << std::endl;
