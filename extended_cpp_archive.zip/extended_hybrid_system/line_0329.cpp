        summary["zeros"] = summary["total"] - summary["ones"];
