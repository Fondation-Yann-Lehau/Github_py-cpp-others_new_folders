     * Exécute la quantification des facteurs abstraits.
