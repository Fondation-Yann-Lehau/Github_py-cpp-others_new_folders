    std::shared_ptr<VisualizationEngine> viz;
