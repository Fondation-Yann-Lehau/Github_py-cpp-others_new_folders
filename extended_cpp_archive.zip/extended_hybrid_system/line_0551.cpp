        return quantified;
