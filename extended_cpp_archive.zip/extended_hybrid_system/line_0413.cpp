        bool collapsedResult = bridge->interpretState(rawResult, fullContext);
