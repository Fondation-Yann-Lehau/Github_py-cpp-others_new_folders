 * Décisions de navigation possibles.
