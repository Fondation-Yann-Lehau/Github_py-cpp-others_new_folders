    void reset() { setState(0); }
