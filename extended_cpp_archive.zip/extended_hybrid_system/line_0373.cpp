            case OperationType::NAND: {
