    OperationType operation;
