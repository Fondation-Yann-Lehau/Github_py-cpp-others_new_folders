    explicit UnifiedExtendedSystem(int animationDelayMs = 150) {
