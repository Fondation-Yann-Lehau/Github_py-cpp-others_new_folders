        // Initialisation des capteurs
