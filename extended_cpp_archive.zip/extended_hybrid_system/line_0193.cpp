        std::cout << "~ ~ ~ (ONDE) ";
