    std::shared_ptr<LogicProcessor> logic;
