                transformed.push_back(std::numeric_limits<double>::infinity());
