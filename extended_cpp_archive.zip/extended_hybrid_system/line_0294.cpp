        viz->visualizeCollapse(binaryState);
