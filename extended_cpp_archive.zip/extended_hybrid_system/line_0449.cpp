            totalExecutionTimeMs / totalOps : 0;
