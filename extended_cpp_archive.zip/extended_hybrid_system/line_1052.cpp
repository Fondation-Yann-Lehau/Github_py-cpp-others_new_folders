        // Durée d'exécution
