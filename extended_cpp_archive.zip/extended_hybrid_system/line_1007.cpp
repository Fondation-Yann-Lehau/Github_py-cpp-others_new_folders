                    throw std::runtime_error("Échec simulé");
