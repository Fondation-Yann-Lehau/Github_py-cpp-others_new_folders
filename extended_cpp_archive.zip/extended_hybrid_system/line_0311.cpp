        bool finalState = obs.collapse();
