    std::cout << "#" << std::string(18, ' ') 
