        auto [leftPower, rightPower] = movements[decision];
