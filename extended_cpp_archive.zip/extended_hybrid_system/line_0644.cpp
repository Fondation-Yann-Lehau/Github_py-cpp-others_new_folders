        variance /= readings.size();
