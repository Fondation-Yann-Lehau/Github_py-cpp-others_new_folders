        // Description du paradigme
