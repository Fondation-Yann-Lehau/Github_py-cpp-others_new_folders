                           int maxRetriesOverride = -1) {
