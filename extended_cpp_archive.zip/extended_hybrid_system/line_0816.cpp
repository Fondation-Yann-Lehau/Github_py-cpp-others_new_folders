                if (readings.at("left") > readings.at("right")) {
