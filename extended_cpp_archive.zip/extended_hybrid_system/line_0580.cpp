    std::uniform_real_distribution<double> dist;
