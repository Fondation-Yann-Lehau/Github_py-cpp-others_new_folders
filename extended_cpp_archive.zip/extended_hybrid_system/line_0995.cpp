        auto result = resilience->executeWithResilience<std::string>(
