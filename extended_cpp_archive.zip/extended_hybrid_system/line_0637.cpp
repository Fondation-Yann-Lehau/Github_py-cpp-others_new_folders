        stats["avg"] = getAverage();
