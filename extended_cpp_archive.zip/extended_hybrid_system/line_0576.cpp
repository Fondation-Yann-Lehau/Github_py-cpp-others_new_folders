    double minVal;
