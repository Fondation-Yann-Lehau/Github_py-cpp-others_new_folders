namespace QuantumSymbolic {
