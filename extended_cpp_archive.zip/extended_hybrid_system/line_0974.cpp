    void runNavigationSimulation(int cycles = 3) {
