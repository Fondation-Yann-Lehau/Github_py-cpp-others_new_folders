     * Retourne un résumé des observations.
