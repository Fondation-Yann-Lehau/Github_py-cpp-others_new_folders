        std::cout << "TEST 5: RÉSILIENCE" << std::endl;
