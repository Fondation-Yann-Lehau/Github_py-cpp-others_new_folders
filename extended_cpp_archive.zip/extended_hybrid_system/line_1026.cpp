        auto logicStats = logic->getStatistics();
