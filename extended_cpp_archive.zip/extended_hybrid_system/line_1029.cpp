                  << static_cast<int>(logicStats["total_operations"]) << std::endl;
