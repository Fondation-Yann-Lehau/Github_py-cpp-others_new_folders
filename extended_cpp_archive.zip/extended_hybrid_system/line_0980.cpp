            std::cout << "\n--- Cycle " << (i + 1) << "/" << cycles << " ---" << std::endl;
