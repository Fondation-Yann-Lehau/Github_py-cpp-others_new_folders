        // Statistiques de résilience
