                          const std::string& label = "Flux") const {
