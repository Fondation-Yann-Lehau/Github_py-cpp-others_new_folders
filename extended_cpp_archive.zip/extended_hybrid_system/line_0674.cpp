    void setState(double value) {
