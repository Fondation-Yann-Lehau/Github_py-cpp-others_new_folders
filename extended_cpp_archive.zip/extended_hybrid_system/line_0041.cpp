 * États binaires fondamentaux avec signification symbolique.
