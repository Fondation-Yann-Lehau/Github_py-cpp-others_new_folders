                    securityCoefficient / 100.0);
