    switch (d) {
