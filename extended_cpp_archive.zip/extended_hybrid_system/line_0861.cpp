        NavigationDecision decision = evaluatePath(readings);
