        for (unsigned char c : data) {
