        std::cout << "\n[Processeur Logique]" << std::endl;
