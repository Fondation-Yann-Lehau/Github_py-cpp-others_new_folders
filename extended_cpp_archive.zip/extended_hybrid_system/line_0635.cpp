        stats["min"] = *std::min_element(readings.begin(), readings.end());
