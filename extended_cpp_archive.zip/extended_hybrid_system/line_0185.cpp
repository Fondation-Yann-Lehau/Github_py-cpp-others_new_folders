        if (!enabled) return;
