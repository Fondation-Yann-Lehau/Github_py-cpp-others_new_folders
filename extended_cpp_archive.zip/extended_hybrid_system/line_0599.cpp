     * Effectue n lectures.
