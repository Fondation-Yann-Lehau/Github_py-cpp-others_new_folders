            if (std::isinf(val) || val <= 0) {
