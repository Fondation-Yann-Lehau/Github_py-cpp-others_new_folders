    std::vector<std::map<std::string, double>> computedSignatures;
