                           const std::vector<bool>& inputs,
