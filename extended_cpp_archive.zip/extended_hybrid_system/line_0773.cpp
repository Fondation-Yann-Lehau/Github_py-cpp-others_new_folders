        actuators["left_motor"] = std::make_unique<ActuatorSimulator>("left_motor");
