                double val = std::exp(static_cast<double>(c) * 
