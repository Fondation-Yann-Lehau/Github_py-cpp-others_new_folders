                      "Évaluation complète du chemin");
