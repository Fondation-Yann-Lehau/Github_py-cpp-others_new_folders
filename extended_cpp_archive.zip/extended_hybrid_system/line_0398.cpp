    OperationResult execute(OperationType operation, 
