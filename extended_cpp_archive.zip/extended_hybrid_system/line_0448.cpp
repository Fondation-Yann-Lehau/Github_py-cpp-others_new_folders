        stats["average_execution_time_ms"] = totalOps > 0 ? 
