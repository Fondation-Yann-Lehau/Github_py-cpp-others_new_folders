    double read() {
