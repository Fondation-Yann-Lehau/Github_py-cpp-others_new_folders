            {NavigationDecision::FORWARD, {80, 80}},
