        for (size_t i = 0; i < 5 && i < transformed.size(); ++i) {
