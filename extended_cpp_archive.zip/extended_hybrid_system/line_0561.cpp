    const std::vector<std::map<std::string, double>>& getAllSignatures() const {
