    std::shared_ptr<QuantumClassicalBridge> bridge;
