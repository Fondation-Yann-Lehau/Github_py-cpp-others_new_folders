 * Données d'un capteur simulé.
