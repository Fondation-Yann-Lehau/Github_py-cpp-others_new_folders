        for (const auto& pair : factors) {
