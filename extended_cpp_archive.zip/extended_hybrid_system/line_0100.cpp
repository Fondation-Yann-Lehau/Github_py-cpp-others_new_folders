 * Convertit une décision de navigation en chaîne.
