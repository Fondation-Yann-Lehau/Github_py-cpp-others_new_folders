        auto factors = quantifier->quantify();
