    SensorSimulator(const std::string& n, double min = 0, double max = 400)
