                if (failCounter < 4) {
