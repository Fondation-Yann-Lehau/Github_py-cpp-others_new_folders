    const std::vector<std::pair<std::chrono::system_clock::time_point, double>>& 
