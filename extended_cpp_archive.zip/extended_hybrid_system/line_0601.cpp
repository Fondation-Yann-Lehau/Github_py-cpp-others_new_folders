    std::vector<double> readN(int n) {
