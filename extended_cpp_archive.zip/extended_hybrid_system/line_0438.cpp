     * Retourne les statistiques du processeur.
