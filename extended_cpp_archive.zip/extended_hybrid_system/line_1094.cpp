    std::cout << std::string(70, '#') << "\n" << std::endl;
