     * Quantifie les facteurs selon le coefficient de sécurité.
