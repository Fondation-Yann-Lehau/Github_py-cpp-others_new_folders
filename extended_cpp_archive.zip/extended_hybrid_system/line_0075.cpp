enum class NavigationDecision {
