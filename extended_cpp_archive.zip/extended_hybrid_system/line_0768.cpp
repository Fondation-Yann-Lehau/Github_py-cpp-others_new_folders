        sensors["front"] = std::make_unique<SensorSimulator>("front_distance");
