                int byteVal = static_cast<int>(
