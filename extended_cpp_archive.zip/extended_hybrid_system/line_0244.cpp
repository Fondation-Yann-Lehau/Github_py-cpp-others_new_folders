            int normalized = static_cast<int>(20 * std::abs(data[i]) / maxVal);
