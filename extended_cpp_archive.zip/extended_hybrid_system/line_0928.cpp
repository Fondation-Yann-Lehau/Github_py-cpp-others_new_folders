        logic->execute(OperationType::NOT, {true});
