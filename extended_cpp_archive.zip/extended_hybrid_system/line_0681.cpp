    void decrement(double delta) { setState(currentState - delta); }
