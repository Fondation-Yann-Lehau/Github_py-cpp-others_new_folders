        viz->visualizeDataFlow(transformed, "Transformation Exponentielle");
