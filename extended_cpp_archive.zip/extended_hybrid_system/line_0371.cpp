                return !inputs[0];
