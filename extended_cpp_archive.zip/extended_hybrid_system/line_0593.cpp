        double value = dist(rng);
