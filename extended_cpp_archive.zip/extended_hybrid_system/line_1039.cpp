        std::cout << "  États |1⟩: " << obsSummary["ones"] << std::endl;
