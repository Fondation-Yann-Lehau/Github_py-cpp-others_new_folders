        case OperationType::XNOR: return "XNOR (⊙)";
