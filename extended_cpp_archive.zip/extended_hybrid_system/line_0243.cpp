        for (size_t i = 0; i < limit; ++i) {
