    std::vector<double> readings;
