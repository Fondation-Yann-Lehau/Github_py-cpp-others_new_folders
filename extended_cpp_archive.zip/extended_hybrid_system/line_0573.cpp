class SensorSimulator {
