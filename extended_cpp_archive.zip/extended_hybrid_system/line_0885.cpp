    std::unique_ptr<SymbolicNavigationSystem> navigation;
