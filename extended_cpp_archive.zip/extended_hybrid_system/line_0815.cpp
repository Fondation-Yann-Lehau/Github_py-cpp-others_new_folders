            } else if (leftClear && rightClear) {
