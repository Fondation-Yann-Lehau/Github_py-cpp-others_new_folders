    ONE = 1,       // Initiation / Structuration / Activation
