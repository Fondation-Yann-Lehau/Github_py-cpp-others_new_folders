     * Lit tous les capteurs.
