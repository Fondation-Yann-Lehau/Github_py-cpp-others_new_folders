        stats["std"] = std::sqrt(variance);
