    std::map<std::string, double> getStatistics() const {
