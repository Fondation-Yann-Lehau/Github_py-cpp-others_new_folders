    std::vector<QuantumObservation> observations;
