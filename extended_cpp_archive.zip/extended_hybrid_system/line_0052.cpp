enum class OperationType {
