 * Simule des capteurs avec génération de valeurs aléatoires.
