        factorsMap["flow"] = 0.577215664901;        // Constante d'Euler-Mascheroni
