    std::vector<NavigationDecision> navigationLog;
