        BinaryState binaryState = state ? BinaryState::ONE : BinaryState::ZERO;
