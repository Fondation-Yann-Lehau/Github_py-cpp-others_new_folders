    void visualizeCollapse(BinaryState state) const {
