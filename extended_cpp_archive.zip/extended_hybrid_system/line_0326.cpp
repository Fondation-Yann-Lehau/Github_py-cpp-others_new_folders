            observations.end(), [](const QuantumObservation& o) {
