     * Ajoute un facteur personnalisé.
