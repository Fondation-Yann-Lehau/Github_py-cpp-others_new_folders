    TRANSITION, // Transition cycloïdale
