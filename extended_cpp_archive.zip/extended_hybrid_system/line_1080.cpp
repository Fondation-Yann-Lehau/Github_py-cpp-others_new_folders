    std::cout << "\n" << std::string(70, '#') << std::endl;
