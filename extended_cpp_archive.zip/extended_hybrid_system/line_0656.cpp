 * Simule des actionneurs avec contrôle d'état.
