    bool isActive = false;
