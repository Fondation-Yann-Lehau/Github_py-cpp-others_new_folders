    bool potentialState;
