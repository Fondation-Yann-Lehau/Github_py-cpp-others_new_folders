    NavigationDecision runCycle() {
