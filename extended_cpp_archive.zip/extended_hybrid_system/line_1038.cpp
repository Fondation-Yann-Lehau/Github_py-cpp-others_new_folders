                  << bridge->getTransitionCount() << std::endl;
