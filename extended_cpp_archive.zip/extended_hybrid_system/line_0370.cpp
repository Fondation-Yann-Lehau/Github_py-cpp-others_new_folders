            case OperationType::NOT: {
