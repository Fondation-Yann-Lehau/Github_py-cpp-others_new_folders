    void describeParadigm() const {
