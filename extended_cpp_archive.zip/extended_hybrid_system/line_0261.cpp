class QuantumClassicalBridge {
