            std::cout << "  " << pair.first << ": " 
