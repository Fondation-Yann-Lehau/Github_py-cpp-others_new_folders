        logic->execute(OperationType::XOR, {true, true});
