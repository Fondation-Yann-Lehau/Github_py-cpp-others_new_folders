            return stats;
