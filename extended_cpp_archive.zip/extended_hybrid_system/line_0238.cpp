        if (maxVal == 0) maxVal = 1;
