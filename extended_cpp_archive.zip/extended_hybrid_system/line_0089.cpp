        case OperationType::OR:   return "OR (∨)";
