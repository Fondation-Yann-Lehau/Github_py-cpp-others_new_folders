            case OperationType::OR: {
