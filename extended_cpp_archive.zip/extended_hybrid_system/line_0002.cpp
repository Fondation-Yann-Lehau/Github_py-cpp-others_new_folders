 * extended_hybrid_system.cpp
