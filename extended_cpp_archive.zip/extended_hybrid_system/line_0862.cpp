        executeMovement(decision);
