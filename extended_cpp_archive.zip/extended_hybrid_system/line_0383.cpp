                return count % 2 == 0;
