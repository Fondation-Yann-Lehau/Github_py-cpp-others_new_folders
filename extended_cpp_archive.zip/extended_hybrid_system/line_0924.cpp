        logic->execute(OperationType::AND, {true, false});
