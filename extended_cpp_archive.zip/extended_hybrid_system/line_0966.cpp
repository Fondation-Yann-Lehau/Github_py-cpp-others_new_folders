                      << std::scientific << std::setprecision(6) 
