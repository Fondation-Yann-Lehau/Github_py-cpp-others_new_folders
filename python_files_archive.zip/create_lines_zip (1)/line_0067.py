        # open with newline='' to avoid Python altering newline bytes on Windows
