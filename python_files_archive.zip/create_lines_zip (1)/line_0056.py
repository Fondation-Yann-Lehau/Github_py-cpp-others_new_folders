    # splitlines(keepends=True) keeps newline characters
