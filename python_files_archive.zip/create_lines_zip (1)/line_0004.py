#   python3 create_lines_zip.py [-s|--skip-empty] [-t|--text] output.zip file1 [file2 ...]
