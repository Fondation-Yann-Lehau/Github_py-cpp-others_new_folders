    if not lines and len(content) == 0:
