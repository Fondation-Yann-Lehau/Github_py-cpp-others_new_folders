def process_file_binary(src_path: Path, out_dir: Path, skip_empty: bool, ext: str) -> None:
