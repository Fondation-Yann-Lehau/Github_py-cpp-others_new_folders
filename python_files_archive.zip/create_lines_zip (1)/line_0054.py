    # Read as text preserving newline chars
