            ext = src_path.suffix.lstrip('.') or "txt"
