EMPTY_BYTES = {b"\n", b"\r\n", b"\r"}
