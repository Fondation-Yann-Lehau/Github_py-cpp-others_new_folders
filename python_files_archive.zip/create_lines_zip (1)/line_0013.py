# - En mode texte (--text) : lit en UTF-8 (défaut d'encodage), splitlines(keepends=True) et écrit chaque ligne
