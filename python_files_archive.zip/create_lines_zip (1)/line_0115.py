    parser.add_argument("sources", nargs="+", help="Source files to split")
