            # Skip creating a file for purely newline-only lines
