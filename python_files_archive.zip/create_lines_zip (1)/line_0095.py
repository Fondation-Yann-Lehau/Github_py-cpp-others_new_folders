                    abs_path = os.path.join(root, file)
