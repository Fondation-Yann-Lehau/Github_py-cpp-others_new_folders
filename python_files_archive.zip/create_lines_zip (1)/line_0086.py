            if text_mode:
