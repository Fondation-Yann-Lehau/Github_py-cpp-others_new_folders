    parser.add_argument("output_zip", help="Output ZIP archive path")
