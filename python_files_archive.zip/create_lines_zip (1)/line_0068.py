        with target.open("w", encoding="utf-8", newline="") as f:
