                    zf.write(abs_path, rel_path)
