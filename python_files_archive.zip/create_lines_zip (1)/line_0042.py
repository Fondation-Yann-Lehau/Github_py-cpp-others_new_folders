            (out_dir / f"line_{1:04d}.{ext}").write_bytes(b"")
