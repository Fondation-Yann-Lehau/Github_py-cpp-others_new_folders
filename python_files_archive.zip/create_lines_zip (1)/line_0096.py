                    rel_path = os.path.relpath(abs_path, tmpdir)
