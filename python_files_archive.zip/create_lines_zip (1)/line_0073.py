    tmpdir = Path(tempfile.mkdtemp(prefix="lines_zip_"))
