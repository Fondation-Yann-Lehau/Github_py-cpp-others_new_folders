        target.write_bytes(line_bytes)
