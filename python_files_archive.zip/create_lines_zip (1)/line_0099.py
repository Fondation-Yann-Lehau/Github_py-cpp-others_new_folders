        print(f"Archive created: {output_zip}")
