EMPTY_STRS = {"\n", "\r\n", "\r"}
