#   dans un fichier texte UTF-8, en préservant les terminaisons (ouvert en newline='').
