    parser.add_argument("-t", "--text", action="store_true",
