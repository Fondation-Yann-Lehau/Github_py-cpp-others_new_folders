#     - si --skip-empty : aucun fichier créé pour ce source;
