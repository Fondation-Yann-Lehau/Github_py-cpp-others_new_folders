    lines = content.splitlines(keepends=True)
