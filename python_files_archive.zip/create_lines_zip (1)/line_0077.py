            if not src_path.is_file():
