    # If file completely empty
