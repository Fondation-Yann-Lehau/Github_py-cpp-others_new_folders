                        help="Text UTF-8 mode: read/write lines as UTF-8 text (preserve newlines).")
