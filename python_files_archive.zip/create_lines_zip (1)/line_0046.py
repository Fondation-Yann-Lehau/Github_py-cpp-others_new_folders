        if skip_empty and line_bytes in EMPTY_BYTES:
