# - Par défaut (mode binaire) : lit chaque fichier en bytes et splitlines(keepends=True), écrit chaque segment
