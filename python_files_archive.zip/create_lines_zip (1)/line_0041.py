        if not skip_empty:
