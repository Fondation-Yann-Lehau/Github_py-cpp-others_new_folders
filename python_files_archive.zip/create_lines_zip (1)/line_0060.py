            (out_dir / f"line_{1:04d}.{ext}").write_text("", encoding="utf-8", newline="")
