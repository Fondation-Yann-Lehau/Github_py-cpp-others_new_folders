            out_dir = tmpdir / name_without_ext
