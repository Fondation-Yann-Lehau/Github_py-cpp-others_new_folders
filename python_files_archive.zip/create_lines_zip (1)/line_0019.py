#     - sinon : on crée line_0001.<ext> vide (comme représentation).
