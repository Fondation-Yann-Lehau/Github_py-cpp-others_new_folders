def create_lines_zip(output_zip: str, sources: List[str], skip_empty: bool, text_mode: bool) -> None:
