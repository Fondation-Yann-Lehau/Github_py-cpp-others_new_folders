            name_without_ext = src_path.stem
