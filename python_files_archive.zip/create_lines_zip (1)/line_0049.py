        target = out_dir / f"line_{idx:04d}.{ext}"
