# - Avec --skip-empty : les lignes qui sont strictement un saut de ligne (b'\n', b'\r\n', b'\r' en binaire
