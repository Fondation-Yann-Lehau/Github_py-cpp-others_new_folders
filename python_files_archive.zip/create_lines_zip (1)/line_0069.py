            f.write(line)
