    parser.add_argument("-s", "--skip-empty", action="store_true",
