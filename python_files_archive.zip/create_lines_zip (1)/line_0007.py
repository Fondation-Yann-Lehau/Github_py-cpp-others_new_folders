#   -s, --skip-empty   : Ne pas créer de fichier pour les lignes composées uniquement d'un saut de ligne.
