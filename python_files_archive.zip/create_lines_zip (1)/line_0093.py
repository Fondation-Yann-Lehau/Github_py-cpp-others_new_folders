            for root, _, files in os.walk(tmpdir):
