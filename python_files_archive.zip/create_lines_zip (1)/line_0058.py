    if not lines and len(text) == 0:
