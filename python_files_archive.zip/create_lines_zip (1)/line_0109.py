    parser = argparse.ArgumentParser(description="Create ZIP where each source line is a separate file.")
