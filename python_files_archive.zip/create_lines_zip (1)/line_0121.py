    create_lines_zip(args.output_zip, args.sources, args.skip_empty, args.text)
