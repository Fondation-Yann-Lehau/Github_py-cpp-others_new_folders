    for idx, line in enumerate(lines, start=1):
