                process_file_binary(src_path, out_dir, skip_empty, ext)
