    content = src_path.read_bytes()
