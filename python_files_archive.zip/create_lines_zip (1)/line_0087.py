                process_file_text(src_path, out_dir, skip_empty, ext)
