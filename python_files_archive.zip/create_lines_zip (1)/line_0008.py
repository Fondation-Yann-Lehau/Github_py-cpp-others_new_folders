#   -t, --text         : Mode texte UTF-8 — lit et écrit les lignes en texte (préserve les terminaisons).
