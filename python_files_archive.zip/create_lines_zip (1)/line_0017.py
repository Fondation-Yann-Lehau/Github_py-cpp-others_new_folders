# - Si un fichier source est vide (0 octet) :
