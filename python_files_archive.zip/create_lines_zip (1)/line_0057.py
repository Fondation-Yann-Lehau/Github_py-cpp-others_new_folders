    lines = text.splitlines(keepends=True)
