    text = src_path.read_text(encoding="utf-8", errors="surrogateescape")
