#   dans line_XXXX.<ext> en bytes (préserve exactement les octets et les terminaisons).
