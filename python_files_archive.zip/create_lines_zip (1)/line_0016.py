#   ou '\n','\r\n','\r' en texte) ne génèrent PAS de fichier.
