        if skip_empty and line in EMPTY_STRS:
