        print("\n--- Annulment Operation (XOR) ---")
