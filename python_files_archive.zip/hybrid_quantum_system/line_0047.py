    system.perform_conjunction(A, B)  # AND: 1 & 1
