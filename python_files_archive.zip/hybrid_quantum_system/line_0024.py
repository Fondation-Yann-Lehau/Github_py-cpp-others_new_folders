        self.visualize_collapse(potential_state)
