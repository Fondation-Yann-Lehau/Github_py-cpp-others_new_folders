        sys.stdout.write("-> ")
