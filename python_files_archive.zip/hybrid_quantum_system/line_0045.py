    system = HybridBinarySystem()
