        print(f"[OBSERVATION] Context: {context}")
