    A, B, C = True, True, False
