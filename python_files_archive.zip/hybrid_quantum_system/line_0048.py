    system.perform_annulment(A, B)    # XOR: 1 ^ 1
