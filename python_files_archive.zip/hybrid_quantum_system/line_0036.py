        print("SYSTEM OUTPUT:", "ACTIVE (1)" if collapsed else "INACTIVE (0)")
