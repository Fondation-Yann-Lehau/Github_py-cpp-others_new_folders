class HybridBinarySystem:
