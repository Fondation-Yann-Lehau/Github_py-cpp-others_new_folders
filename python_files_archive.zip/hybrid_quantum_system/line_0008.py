    def visualize_collapse(self, final_state: bool):
