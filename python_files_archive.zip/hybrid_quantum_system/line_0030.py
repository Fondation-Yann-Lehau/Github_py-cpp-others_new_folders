        self.quantum.describe_quantum_transition()
