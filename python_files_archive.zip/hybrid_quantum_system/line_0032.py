    def perform_conjunction(self, signal_a, signal_b):
