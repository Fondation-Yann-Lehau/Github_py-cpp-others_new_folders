        sys.stdout.write(" | Processing: ~ ~ ~ (Wave) ")
