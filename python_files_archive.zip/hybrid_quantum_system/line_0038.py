    def perform_annulment(self, signal_a, signal_b):
