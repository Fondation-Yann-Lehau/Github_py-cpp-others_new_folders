        sys.stdout.write("-> (o) (Transition) ")
