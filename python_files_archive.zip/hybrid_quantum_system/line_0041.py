        collapsed = self.quantum.interpret_classical_state(raw_result, "Difference analysis")
