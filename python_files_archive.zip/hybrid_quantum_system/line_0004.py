class QuantumBinaryConcept:
