        raw_result = signal_a ^ signal_b
