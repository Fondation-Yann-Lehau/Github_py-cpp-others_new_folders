    def describe_quantum_transition(self):
