        print("\n--- Conjunction Operation (AND) ---")
