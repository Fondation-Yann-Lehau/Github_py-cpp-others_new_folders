        return potential_state
