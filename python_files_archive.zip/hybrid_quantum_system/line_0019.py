        print("[ 1 ] (FIXED)" if final_state else "[ 0 ] (ANNULLED)")
