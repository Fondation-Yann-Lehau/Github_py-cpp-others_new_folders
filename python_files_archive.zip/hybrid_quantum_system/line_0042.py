        print("SYSTEM OUTPUT:", "DIFFERENCE (1)" if collapsed else "ANNULATION (0)")
