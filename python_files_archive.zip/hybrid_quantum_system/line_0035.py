        collapsed = self.quantum.interpret_classical_state(raw_result, "Conjunction analysis")
