        self.quantum = QuantumBinaryConcept()
