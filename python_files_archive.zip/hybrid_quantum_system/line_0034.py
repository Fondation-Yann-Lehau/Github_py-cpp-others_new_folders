        raw_result = signal_a and signal_b
