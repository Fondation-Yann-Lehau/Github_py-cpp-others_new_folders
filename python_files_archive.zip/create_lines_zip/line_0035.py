            # If file is empty, ensure we create zero or one line file? We'll create 0 files in that case.
