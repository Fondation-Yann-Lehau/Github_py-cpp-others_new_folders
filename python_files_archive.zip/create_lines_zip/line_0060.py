        print("Usage: python3 create_lines_zip.py output.zip file1 [file2 ...]")
