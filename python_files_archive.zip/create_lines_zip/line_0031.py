            with open(src, 'rb') as f:
