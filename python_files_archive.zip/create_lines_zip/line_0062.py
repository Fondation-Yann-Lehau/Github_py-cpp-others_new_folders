    output_zip = sys.argv[1]
