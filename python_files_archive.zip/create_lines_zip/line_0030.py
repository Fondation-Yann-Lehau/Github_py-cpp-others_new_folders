            # Read in binary to preserve exact bytes and line endings
