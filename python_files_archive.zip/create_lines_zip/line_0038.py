                line_filename = dirpath / f"line_{1:04d}.{ext}"
