            name_without_ext = p.stem
