            dirpath = Path(tmpdir) / name_without_ext
