# - Lit chaque fichier en binaire et découpe en "lignes" via splitlines(keepends=True).
