                    line_filename = dirpath / f"line_{i:04d}.{ext}"
