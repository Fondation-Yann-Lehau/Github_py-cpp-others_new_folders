# - Chaque segment de ligne devient line_0001.<ext>, line_0002.<ext>, ... et contient exactement les octets lus.
