                line_filename.write_bytes(b'')
