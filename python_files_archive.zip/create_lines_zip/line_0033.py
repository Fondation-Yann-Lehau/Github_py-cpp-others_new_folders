            # splitlines(keepends=True) preserves newline bytes; handles last line without newline
