        shutil.rmtree(tmpdir)
