            ext = p.suffix.lstrip('.') or 'txt'
