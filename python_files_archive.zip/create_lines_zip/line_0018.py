    tmpdir = tempfile.mkdtemp(prefix="lines_zip_")
