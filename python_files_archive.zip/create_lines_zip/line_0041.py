                for i, line_bytes in enumerate(lines, start=1):
