            p = Path(src)
