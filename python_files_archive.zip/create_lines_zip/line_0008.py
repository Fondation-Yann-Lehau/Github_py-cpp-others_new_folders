# - Crée un répertoire par fichier source (nom = nom_sans_extension).
