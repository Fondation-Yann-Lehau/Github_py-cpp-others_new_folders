def create_lines_zip(output_zip: str, sources):
