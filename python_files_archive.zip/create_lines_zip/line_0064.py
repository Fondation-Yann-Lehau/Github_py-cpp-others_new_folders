    create_lines_zip(output_zip, sources)
