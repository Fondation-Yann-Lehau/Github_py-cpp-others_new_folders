                content = f.read()
