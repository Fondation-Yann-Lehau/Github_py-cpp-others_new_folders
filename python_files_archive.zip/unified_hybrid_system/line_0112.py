            ("(•)", "TRANSITION"),
