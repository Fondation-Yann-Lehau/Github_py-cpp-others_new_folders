        ones = sum(1 for r in self._history if r.value == BinaryState.ONE)
