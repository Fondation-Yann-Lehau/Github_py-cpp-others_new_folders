class SecurityEvaluator:
