        signature = sum(v * (i + 1) for i, v in enumerate(values)) % (2**32)
