        self._evaluations: List[ProcessingResult] = []
