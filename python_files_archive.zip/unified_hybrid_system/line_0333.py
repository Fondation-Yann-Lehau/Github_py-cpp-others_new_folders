    Analyseur et catégorisateur d'entités textuelles.
