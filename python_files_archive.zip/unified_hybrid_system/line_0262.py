                if byte > self.overflow_threshold:
