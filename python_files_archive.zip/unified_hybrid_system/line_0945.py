            coefficient=config.get("quantification_coefficient", 1.0)
