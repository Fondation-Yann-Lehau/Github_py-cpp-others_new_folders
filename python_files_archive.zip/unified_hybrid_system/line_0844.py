        Utilise la logique AND/XOR pour la décision.
