                OperationType.XOR,
