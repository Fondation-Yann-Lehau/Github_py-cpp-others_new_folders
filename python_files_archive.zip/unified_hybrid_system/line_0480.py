    Quantificateur de facteurs abstraits avec mapping configurable.
