        self.delay = animation_delay
