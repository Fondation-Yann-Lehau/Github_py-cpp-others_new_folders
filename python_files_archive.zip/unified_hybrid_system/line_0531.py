    def compute_composite_score(self) -> float:
