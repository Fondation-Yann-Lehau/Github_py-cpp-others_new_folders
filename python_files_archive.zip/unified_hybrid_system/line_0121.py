            time.sleep(self.delay)
