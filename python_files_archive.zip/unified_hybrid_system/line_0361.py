            ProcessingResult avec les catégories identifiées
