    MANUAL = auto()
