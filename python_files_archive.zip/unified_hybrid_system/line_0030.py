    """États binaires classiques avec sémantique enrichie."""
