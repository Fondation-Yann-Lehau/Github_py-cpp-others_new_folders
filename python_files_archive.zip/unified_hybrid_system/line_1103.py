        if fail_count[0] < 4:
