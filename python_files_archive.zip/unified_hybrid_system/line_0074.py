        """Effondrement de la fonction d'onde."""
