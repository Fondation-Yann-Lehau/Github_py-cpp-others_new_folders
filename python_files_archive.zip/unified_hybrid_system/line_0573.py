        self.added_paths.append(path)
