            context: Contexte de l'observation
