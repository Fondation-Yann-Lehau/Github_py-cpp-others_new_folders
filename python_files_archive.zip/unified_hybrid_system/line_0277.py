                    "min_value": min(transformed) if transformed else 0,
