    def probability_zero(self) -> float:
