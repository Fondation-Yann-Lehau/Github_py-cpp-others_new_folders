        print(f"  Operation: {inputs_str} = {int(output)}")
