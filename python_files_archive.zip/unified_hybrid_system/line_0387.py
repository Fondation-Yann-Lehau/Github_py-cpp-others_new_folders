    def get_category_summary(self) -> Dict[str, int]:
