            fallback_value: Valeur de secours
