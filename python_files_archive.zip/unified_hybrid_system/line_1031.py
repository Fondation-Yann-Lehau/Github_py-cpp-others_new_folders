        "quantification_coefficient": 1.0
