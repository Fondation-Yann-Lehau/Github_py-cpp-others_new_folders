    # --- Rapport Final ---
