                time.sleep(0.1 * (attempt + 1))  # Backoff exponentiel simplifié
