        return {cat: len(items) for cat, items in self.categories.items()}
