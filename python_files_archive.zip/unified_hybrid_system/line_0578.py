            context=f"Path added: {path}",
