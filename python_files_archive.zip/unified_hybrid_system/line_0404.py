            "professional_network": 9.2,
