            "entity_categories": self.entity_analyzer.get_category_summary(),
