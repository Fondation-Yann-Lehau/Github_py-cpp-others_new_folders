    """Représentation d'un état quantique symbolique."""
