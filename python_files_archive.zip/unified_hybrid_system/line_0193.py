            potential_state: État potentiel calculé
