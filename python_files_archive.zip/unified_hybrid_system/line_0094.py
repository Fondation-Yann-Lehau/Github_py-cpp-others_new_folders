    """Moteur de visualisation ASCII pour les transitions et processus."""
