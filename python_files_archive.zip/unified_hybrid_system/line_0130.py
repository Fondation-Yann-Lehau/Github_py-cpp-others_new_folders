        """Visualisation du flux de données."""
