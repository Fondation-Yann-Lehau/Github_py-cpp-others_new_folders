            self.patterns[category] = []
