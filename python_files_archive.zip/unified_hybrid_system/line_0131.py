        if not self.enabled or not data_points:
