            navigation->runCycle();
