        if (inputs.empty()) {
