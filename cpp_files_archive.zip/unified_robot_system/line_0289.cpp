        bool left_clear = readings.at("left") >= obstacle_threshold;
