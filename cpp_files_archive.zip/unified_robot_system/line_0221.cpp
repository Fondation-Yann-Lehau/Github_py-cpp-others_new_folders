    std::string getName() const { return name; }
