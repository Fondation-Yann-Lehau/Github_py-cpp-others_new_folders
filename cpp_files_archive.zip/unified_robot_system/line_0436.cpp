        logic->execute(OperationType::NOT, {true}, "NOT(1)");
