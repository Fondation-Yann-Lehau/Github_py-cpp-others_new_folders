    UnifiedRobotSystem(int animation_delay = 150) {
