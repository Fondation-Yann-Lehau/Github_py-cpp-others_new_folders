                decision = (readings.at("left") > readings.at("right")) 
