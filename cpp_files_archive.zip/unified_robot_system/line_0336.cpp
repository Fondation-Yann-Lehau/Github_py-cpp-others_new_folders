        static const std::map<NavigationDecision, std::string> names = {
