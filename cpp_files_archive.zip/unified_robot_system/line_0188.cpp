                result = !result;
