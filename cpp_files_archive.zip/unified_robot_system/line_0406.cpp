    std::unique_ptr<ResilienceManager> resilience;
