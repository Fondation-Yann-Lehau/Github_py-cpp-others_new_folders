class RandomGenerator {
