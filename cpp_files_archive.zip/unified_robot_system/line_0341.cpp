            {NavigationDecision::STOP, "STOP"}
