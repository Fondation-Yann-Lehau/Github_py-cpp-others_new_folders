            case OperationType::NOR:
