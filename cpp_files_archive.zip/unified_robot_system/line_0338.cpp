            {NavigationDecision::TURN_LEFT, "TURN_LEFT"},
