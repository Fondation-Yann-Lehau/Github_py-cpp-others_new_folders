        bool right_clear = readings.at("right") >= obstacle_threshold;
