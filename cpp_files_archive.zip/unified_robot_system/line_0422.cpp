        std::cout << "[SYSTEM] All components initialized" << std::endl;
