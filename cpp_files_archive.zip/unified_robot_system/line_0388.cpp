        std::cout << "[RESILIENCE] Using fallback value" << std::endl;
