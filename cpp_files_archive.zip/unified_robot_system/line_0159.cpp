    BinaryState execute(OperationType op, const std::vector<bool>& inputs,
