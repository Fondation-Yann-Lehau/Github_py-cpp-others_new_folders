    NavigationDecision evaluatePath(const std::map<std::string, double>& readings) {
