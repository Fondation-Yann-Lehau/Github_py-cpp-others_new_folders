            case OperationType::AND:
