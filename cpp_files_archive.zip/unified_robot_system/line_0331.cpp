        if (it != movements.end()) {
