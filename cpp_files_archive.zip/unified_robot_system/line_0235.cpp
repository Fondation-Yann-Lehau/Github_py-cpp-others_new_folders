    ActuatorSimulator(const std::string& n) : name(n), state(0), active(false) {}
