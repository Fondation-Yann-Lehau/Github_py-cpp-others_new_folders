        static const std::map<NavigationDecision, std::pair<double, double>> movements = {
