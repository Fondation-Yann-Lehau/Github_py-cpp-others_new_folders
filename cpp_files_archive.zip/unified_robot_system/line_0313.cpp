                decision = NavigationDecision::REVERSE;
