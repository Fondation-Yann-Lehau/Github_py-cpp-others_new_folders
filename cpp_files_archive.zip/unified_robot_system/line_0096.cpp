            {OperationType::NAND, "NAND (⊼)"},
