        std::cout << "LOGIC OPERATIONS TEST" << std::endl;
