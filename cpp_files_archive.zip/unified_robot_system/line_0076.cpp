        std::cout << "-> (•) (TRANSITION) "; std::cout.flush();
