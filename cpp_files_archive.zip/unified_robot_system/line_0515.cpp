    std::cout << "#" << std::string(18, ' ') << "DEMONSTRATION COMPLETE" << std::string(18, ' ') << "#" << std::endl;
