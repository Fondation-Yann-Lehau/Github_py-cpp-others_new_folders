        int fail_counter = 0;
