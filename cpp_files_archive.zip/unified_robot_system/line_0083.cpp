            std::cout << "[ 0 ] (ANNULLED)" << std::endl;
