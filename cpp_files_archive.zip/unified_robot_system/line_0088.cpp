    void visualizeOperation(OperationType op, bool result) const {
