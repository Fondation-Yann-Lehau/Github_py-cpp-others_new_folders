    void executeMovement(NavigationDecision decision) {
