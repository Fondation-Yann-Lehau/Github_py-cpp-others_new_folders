        std::cout << "Failure test result: " << fail_result << std::endl;
