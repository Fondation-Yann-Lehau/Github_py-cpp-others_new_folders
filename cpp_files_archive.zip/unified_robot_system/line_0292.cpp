        // Évaluation avec logique AND/XOR
