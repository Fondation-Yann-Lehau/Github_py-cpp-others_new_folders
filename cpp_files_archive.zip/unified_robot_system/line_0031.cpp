enum class SystemMode { AUTONOMOUS, MANUAL, HYBRID };
