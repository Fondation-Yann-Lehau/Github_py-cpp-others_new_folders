 * Architecture technique combinant :
