        std::cout << "  - State |0>: Integration/Completion" << std::endl;
