        logic->execute(OperationType::AND, {true, false}, "AND(1,0)");
