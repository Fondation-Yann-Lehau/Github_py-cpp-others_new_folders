            logic->execute(OperationType::XOR, {left_clear, right_clear},
