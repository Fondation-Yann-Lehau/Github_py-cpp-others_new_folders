    bool isActive() const { return active; }
