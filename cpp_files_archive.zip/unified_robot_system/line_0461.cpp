        std::cout << "Success test result: " << success << std::endl;
