        BinaryState state = potential ? BinaryState::ONE : BinaryState::ZERO;
