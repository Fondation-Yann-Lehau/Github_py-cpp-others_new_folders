        std::cout << "[NAVIGATION] Executing: " << names.at(decision) << std::endl;
