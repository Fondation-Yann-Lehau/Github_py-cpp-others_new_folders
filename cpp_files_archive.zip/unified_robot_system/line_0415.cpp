        bridge = std::make_shared<QuantumClassicalBridge>(viz);
