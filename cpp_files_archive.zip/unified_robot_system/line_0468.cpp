                if (fail_counter < 4) {
