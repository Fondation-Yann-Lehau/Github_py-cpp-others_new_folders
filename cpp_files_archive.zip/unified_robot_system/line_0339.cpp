            {NavigationDecision::TURN_RIGHT, "TURN_RIGHT"},
