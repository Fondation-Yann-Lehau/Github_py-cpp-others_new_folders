        actuators["right_motor"] = std::make_unique<ActuatorSimulator>("right_motor");
