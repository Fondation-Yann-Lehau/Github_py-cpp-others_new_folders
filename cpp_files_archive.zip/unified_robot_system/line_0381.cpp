                std::cout << "[RESILIENCE] Attempt " << (attempt + 1) 
