    std::map<OperationType, int> getStatistics() const { return operation_counts; }
