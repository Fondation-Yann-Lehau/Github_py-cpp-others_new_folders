    ResilienceManager() : error_count(0), recovery_count(0) {}
