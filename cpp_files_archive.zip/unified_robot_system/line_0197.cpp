        operation_counts[op]++;
