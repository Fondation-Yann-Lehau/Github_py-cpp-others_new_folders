                    throw std::runtime_error("Simulated failure");
