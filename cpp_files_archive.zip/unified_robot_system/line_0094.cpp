            {OperationType::XOR, "XOR (⊕)"},
