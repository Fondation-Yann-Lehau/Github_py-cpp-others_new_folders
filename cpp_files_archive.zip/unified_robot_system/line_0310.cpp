                          ? NavigationDecision::TURN_LEFT 
