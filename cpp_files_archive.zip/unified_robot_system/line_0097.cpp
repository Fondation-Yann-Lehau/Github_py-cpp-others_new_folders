            {OperationType::NOR, "NOR (⊽)"}
