        std::cout << "Resilience errors: " << resilience->getErrorCount() << std::endl;
