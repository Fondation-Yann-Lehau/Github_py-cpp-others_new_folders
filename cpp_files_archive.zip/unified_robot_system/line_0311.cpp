                          : NavigationDecision::TURN_RIGHT;
