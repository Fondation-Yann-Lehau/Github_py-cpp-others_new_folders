        std::cout << "\n[OBSERVATION #" << transition_count 
