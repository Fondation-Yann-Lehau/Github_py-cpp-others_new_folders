    int transition_count;
