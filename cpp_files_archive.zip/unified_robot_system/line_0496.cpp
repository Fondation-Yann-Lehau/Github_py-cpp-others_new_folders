    std::cout << "#" << std::string(20, ' ') << "SYSTEM DEMONSTRATION" << std::string(20, ' ') << "#" << std::endl;
