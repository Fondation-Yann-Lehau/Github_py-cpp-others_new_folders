    template<typename Func, typename Fallback>
