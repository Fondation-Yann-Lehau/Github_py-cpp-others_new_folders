            } else if (right_clear && !left_clear) {
