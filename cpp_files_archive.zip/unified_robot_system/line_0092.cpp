            {OperationType::AND, "AND (∧)"},
