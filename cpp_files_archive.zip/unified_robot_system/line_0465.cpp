        auto fail_result = resilience->executeWithResilience(
