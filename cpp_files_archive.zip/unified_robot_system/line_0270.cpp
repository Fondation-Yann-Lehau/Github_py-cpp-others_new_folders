        sensors["left"] = std::make_unique<SensorSimulator>("left_distance");
