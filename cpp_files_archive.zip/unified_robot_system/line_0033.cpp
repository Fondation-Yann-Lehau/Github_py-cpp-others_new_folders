enum class NavigationDecision { FORWARD, TURN_LEFT, TURN_RIGHT, REVERSE, STOP };
