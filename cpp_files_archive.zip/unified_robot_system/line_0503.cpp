    system.runLogicTests();
