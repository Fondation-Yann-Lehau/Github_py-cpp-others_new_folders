    double getState() const { return state; }
