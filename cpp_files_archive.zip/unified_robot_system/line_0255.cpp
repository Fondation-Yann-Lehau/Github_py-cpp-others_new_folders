    SystemMode mode;
