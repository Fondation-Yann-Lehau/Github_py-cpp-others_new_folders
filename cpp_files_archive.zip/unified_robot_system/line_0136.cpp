        viz->visualizeCollapse(state);
