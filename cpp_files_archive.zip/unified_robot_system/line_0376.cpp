        for (int attempt = 0; attempt < max_retries; attempt++) {
