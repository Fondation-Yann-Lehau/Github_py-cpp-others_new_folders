    std::map<std::string, std::unique_ptr<SensorSimulator>> sensors;
