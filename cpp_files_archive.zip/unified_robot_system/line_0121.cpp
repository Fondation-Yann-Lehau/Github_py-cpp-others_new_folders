        std::cout << "QUANTUM-CLASSICAL BRIDGE INITIALIZED" << std::endl;
