        std::cout << "\n[SENSORS] F:" << std::fixed << std::setprecision(1)
