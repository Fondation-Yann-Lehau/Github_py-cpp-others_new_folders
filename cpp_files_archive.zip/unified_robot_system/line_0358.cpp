    size_t getNavigationLogSize() const { return navigation_log.size(); }
