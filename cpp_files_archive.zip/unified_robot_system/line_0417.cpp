        navigation = std::make_unique<RobotNavigationSystem>(bridge, logic);
