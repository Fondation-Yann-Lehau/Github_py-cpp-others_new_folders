                for (bool b : inputs) sum += b ? 1 : 0;
