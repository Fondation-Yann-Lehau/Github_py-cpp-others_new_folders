        actuators["servo"] = std::make_unique<ActuatorSimulator>("servo");
