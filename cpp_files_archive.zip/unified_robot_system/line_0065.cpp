        : delay_ms(delay), enabled(enable) {}
