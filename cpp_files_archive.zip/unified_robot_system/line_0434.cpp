        logic->execute(OperationType::XOR, {true, false}, "XOR(1,0)");
