        auto readings = readAllSensors();
