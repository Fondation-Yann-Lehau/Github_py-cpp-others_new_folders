    void runCycle() {
