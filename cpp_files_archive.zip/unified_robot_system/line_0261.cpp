    std::vector<NavigationDecision> navigation_log;
