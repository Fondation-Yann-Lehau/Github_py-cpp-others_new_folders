            case OperationType::NAND:
