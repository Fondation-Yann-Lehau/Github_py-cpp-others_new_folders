        navigation_log.push_back(decision);
