    std::map<OperationType, int> operation_counts;
