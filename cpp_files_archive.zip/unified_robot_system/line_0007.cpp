 * - Communication série et Wi-Fi
