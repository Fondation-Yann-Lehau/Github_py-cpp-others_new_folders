    LogicProcessor(std::shared_ptr<QuantumClassicalBridge> b,
