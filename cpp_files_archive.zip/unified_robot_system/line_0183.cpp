                result = !inputs[0];
