        std::string fullContext = context.empty() ? "Logic operation" : context;
