    std::map<std::string, std::unique_ptr<ActuatorSimulator>> actuators;
