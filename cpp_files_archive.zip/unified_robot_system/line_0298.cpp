        if (front_clear) {
