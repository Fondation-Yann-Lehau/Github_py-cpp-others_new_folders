            readings[name] = sensor->read();
