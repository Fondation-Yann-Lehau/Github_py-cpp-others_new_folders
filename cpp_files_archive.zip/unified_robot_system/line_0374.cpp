    auto executeWithResilience(Func operation, Fallback fallback, 
