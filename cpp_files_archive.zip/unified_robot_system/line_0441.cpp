        std::cout << "ROBOT NAVIGATION SIMULATION" << std::endl;
