                               int max_retries = 3) -> decltype(fallback) {
