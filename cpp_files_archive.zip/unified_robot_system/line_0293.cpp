        logic->execute(OperationType::AND, {front_clear, left_clear, right_clear},
