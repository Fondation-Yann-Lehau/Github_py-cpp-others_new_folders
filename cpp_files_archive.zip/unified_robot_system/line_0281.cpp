        for (auto& [name, sensor] : sensors) {
