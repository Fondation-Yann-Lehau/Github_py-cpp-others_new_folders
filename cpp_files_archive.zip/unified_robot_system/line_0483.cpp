        std::cout << "Transitions: " << bridge->getTransitionCount() << std::endl;
