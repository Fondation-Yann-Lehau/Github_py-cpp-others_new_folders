            actuators["right_motor"]->setState(it->second.second);
