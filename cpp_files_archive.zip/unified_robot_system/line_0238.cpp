        state = std::max(0.0, std::min(100.0, value));
