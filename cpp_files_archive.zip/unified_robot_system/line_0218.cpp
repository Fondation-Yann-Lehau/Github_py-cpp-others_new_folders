        : name(n), rng(min, max) {}
