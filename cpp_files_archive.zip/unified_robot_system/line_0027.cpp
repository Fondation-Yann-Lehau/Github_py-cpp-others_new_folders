enum class BinaryState { ZERO = 0, ONE = 1 };
