 * - Gestion d'exceptions et résilience
