        return bridge->interpretState(result, fullContext);
