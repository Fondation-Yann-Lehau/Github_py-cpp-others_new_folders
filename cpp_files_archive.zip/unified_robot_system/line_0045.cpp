        : gen(std::random_device{}()), dist(min, max) {}
