    bool active;
