            {OperationType::NOT, "NOT (¬)"},
