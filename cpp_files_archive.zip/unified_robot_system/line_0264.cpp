    RobotNavigationSystem(std::shared_ptr<QuantumClassicalBridge> b,
