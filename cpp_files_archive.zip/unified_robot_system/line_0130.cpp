        transition_count++;
