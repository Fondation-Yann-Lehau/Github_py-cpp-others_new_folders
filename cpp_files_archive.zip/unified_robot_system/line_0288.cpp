        bool front_clear = readings.at("front") >= obstacle_threshold;
