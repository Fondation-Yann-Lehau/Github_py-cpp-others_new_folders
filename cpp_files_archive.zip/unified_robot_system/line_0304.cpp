            if (left_clear && !right_clear) {
