    int getRecoveryCount() const { return recovery_count; }
