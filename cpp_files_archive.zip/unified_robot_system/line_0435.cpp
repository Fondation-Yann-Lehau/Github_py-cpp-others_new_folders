        logic->execute(OperationType::OR, {false, false, true}, "OR(0,0,1)");
