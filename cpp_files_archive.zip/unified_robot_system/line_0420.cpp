        bridge->describeParadigm();
