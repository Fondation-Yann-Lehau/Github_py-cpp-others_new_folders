            {NavigationDecision::REVERSE, {60, 60}},
