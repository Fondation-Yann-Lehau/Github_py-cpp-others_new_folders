        std::cout << "Paradigm: Binary states as cycloidal transitions" << std::endl;
