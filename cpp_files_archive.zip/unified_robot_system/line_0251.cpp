class RobotNavigationSystem {
