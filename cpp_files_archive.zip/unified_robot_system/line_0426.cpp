    void runLogicTests() {
