        viz = std::make_shared<VisualizationEngine>(animation_delay);
