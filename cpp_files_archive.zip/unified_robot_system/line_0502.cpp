    // Test 1: Opérations logiques
