            throw std::invalid_argument("No inputs provided");
