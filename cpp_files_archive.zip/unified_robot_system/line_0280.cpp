        std::map<std::string, double> readings;
