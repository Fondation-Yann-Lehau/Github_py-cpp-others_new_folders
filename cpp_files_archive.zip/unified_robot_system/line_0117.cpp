        : viz(v ? v : std::make_shared<VisualizationEngine>()), transition_count(0) {}
