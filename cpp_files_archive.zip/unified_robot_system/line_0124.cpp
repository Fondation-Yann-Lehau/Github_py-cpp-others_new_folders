        std::cout << "  - State |1>: Initiation/Structuration" << std::endl;
