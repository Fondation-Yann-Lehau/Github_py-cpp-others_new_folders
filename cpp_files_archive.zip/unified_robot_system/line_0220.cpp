    double read() { return rng.generate(); }
