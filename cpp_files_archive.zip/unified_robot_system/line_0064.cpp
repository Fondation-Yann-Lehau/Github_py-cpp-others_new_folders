    VisualizationEngine(int delay = 150, bool enable = true) 
