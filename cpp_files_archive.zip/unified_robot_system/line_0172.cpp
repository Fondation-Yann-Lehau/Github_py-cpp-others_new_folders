            case OperationType::OR:
