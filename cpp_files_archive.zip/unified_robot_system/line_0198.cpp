        viz->visualizeOperation(op, result);
