 * - Navigation autonome avec architecture comportementale
