    // Test 2: Simulation de navigation
