    RandomGenerator(double min = 0.0, double max = 400.0) 
