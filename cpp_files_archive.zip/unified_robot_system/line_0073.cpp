        std::cout << "~ ~ ~ (WAVE) "; std::cout.flush();
