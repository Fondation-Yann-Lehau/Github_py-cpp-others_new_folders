    // Test 3: Test de résilience
