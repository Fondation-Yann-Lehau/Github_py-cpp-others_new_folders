        active = state > 0;
