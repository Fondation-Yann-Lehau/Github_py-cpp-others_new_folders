    double generate() { return dist(gen); }
