        : bridge(b), logic(l), mode(SystemMode::AUTONOMOUS), obstacle_threshold(40.0) {
