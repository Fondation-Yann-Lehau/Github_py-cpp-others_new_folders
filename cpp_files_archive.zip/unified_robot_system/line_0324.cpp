            {NavigationDecision::TURN_LEFT, {40, 80}},
