        std::cout << "Resilience recoveries: " << resilience->getRecoveryCount() << std::endl;
