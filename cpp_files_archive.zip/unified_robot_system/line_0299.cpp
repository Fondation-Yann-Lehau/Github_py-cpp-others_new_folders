            decision = NavigationDecision::FORWARD;
