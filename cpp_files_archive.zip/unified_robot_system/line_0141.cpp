    int getTransitionCount() const { return transition_count; }
