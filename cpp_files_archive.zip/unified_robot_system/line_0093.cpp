            {OperationType::OR, "OR (∨)"},
