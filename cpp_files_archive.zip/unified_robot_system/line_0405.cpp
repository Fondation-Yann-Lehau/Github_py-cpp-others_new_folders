    std::unique_ptr<RobotNavigationSystem> navigation;
