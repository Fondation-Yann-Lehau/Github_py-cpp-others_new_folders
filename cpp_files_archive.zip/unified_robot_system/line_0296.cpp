        NavigationDecision decision;
