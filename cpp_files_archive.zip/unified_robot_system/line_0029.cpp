enum class OperationType { AND, OR, XOR, NOT, NAND, NOR };
