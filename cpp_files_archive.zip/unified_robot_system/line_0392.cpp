    int getErrorCount() const { return error_count; }
