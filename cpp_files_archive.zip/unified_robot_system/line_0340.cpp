            {NavigationDecision::REVERSE, "REVERSE"},
