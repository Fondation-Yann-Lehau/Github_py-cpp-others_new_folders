            [&fail_counter]() -> std::string {
