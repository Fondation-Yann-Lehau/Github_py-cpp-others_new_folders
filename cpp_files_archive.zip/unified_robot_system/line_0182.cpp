            case OperationType::NOT:
