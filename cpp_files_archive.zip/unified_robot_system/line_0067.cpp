    void setEnabled(bool enable) { enabled = enable; }
