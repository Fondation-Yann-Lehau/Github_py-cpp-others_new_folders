        return readings;
