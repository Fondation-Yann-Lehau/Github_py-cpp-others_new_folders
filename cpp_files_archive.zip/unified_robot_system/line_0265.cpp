                          std::shared_ptr<LogicProcessor> l)
