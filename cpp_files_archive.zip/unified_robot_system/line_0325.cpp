            {NavigationDecision::TURN_RIGHT, {80, 40}},
