            actuators["left_motor"]->setState(it->second.first);
