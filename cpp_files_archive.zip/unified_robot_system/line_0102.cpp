        std::cout << "  [" << opName << "] Result: " << result << std::endl;
