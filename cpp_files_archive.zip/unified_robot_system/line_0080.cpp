        if (state == BinaryState::ONE) {
