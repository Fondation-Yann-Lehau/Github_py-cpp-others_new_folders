        std::cout << "Navigation log size: " << navigation->getNavigationLogSize() << std::endl;
