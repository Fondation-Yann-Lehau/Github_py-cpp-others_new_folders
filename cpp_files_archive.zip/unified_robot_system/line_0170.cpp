                for (bool b : inputs) result = result && b;
