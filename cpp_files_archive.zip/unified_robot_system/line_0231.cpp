    double state;
