 * - Logique binaire classique avec transitions quantique-symbolique
