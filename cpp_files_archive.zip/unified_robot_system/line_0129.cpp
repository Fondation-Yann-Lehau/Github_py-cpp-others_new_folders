    BinaryState interpretState(bool potential, const std::string& context) {
