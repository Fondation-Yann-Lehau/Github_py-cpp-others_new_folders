        sensors["right"] = std::make_unique<SensorSimulator>("right_distance");
