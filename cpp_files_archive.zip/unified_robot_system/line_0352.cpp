                  << " R:" << readings["right"] << std::endl;
