            (OperationType.NOT, [True]),
