class IQuantumInterface(ABC):
