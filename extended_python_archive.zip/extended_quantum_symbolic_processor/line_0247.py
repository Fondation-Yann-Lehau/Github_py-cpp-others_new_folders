    def visualize_data_flow(self, data: List[float], label: str = "Flux") -> None:
