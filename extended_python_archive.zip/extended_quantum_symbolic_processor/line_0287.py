        print(self._paradigm_description)
