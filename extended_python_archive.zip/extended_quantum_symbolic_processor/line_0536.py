        self._random = random.Random()
