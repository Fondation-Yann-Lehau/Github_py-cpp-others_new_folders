    def increment(self, delta: float) -> None:
