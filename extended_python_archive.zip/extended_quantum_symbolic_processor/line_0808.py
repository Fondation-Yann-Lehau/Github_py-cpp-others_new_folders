            (OperationType.AND, [True, True]),
