        self.logic.execute(OperationType.AND, 
