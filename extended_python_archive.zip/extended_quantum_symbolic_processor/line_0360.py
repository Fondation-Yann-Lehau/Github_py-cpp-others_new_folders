            result = any(inputs)
