    """Rapport de l'état du système."""
