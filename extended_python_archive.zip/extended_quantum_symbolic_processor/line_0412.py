        """Exécute un lot d'opérations."""
