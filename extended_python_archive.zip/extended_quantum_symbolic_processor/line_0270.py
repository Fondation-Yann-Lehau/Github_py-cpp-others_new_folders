    def __init__(self, visualization: Optional[VisualizationEngine] = None):
