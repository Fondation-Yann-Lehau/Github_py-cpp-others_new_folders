        binary_state = BinaryState.ONE if state else BinaryState.ZERO
