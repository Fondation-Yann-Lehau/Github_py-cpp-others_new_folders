        """Lit tous les capteurs."""
