        ones = sum(1 for o in self.observations if o.observed_state)
