    def __init__(self, name: str, min_val: float = 0, max_val: float = 400):
