            'resonance': 1.618033988749,  # Nombre d'or
