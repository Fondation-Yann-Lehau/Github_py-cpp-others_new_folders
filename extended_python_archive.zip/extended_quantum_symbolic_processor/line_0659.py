class NavigationDecision(Enum):
