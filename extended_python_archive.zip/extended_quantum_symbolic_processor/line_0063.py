    BATCH = auto()
