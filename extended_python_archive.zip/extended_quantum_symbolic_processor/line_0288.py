        return self._paradigm_description
