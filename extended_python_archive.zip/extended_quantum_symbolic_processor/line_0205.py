        sys.stdout.write(self.animation_frames[TransitionPhase.WAVE] + " ")
