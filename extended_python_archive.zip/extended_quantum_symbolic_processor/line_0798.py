        print(f"[SYSTÈME] Tous les composants initialisés à {self.start_time.isoformat()}")
