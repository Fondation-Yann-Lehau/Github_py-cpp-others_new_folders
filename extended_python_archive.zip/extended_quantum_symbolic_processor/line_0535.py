        self.readings: List[float] = []
