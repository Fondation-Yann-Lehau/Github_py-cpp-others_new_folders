            TransitionPhase.FIXED: lambda s: f"[ {1 if s else 0} ] ({'CRISTALLISÉ' if s else 'ANNULÉ'})"
