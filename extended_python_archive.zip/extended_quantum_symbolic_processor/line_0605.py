    def get_history(self) -> List[Tuple[datetime.datetime, float]]:
