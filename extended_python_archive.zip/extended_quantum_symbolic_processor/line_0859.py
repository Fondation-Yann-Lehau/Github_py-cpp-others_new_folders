        print("TEST 5: RÉSILIENCE")
