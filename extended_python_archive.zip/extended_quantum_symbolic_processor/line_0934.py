    print("#" + " " * 20 + "DÉMONSTRATION DU SYSTÈME" + " " * 20 + "#")
