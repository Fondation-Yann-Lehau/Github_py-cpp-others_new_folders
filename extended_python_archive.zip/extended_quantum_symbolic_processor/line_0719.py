                if readings.get("left", 0) > readings.get("right", 0):
