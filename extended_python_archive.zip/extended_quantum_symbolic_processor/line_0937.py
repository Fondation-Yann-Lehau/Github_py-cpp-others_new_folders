    # Création et exécution du système unifié
