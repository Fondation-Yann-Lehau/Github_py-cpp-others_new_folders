        """Décrit le paradigme du système."""
