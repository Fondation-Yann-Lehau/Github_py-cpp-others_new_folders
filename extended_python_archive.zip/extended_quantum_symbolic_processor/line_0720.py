                    decision = NavigationDecision.TURN_LEFT
