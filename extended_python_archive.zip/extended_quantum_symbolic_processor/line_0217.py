        self._sleep(self.delay_ms)
