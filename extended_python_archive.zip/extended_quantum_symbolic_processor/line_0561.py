        avg = self.get_average()
