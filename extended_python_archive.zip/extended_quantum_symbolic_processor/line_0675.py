        self.navigation_log: List[NavigationDecision] = []
