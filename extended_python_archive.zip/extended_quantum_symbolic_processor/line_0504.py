            key: value * self.security_coefficient 
