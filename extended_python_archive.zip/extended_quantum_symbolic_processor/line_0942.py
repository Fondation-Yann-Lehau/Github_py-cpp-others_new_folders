    print("#" + " " * 18 + "DÉMONSTRATION TERMINÉE" + " " * 18 + "#")
