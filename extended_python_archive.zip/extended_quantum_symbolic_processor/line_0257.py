            bar = "█" * normalized
