        readings = self.read_all_sensors()
