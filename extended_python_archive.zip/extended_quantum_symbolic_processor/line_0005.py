Extension complète du système de traitement symbolique quantique-binaire.
