    NOR = auto()    # Non-disjonction
