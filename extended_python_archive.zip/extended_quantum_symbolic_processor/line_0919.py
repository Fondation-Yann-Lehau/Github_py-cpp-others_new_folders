        """Exécute tous les tests."""
