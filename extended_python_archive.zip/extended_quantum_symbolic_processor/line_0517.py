        content = json.dumps(sorted_items)
