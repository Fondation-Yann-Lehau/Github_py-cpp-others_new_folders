        self.bridge = bridge
