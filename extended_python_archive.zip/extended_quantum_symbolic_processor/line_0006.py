Ce fichier développe les concepts de transition cycloidale, de conjonction/annulation
