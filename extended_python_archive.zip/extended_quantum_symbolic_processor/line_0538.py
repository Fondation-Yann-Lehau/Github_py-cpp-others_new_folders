    def set_seed(self, seed: int) -> None:
