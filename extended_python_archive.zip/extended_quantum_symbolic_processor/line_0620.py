        self.recovery_count = 0
