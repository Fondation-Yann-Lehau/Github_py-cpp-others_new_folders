        """Retourne et affiche la description du paradigme."""
