        result = OperationResult(
