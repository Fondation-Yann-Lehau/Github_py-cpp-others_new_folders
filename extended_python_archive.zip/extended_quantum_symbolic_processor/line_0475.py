        return [self.transform(data) for data in data_list]
