        C'est le moment de 'l'observation' qui force l'effondrement.
