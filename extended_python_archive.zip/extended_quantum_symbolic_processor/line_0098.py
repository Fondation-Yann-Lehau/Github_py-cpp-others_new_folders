        self.value = new_value
