class QuantumObservation:
