        print(f"\n[Temps d'exécution]: {duration.total_seconds():.2f} secondes")
