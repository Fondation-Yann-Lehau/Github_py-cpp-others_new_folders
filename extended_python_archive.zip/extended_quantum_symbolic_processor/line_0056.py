    COLLAPSE = auto()   # Effondrement vers état fixe
