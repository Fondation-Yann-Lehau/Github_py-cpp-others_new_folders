            result = sum(inputs) % 2 == 1
