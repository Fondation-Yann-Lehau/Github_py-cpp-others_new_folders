            "recovery_count": self.recovery_count,
