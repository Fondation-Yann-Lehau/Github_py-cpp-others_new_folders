            'stability': 2.342e-8,
