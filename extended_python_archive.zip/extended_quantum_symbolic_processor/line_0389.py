        collapsed_result = self.bridge.interpret_state(raw_result, full_context)
