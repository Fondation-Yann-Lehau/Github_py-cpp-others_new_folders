        """Exécute des tests sur les opérations logiques."""
