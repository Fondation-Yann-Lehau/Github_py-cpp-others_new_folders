            return {"count": 0, "min": 0, "max": 0, "avg": 0, "std": 0}
