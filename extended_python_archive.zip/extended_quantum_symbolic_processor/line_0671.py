                 logic: LogicProcessor):
