        return self.observed_state
