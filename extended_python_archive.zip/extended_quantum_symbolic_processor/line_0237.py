            OperationType.XOR: "⊕",
