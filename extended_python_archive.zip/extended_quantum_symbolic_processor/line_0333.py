            "zeros": len(self.observations) - ones,
