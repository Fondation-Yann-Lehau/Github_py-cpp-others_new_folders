        self.navigation = SymbolicNavigationSystem(bridge=self.bridge, logic=self.logic)
