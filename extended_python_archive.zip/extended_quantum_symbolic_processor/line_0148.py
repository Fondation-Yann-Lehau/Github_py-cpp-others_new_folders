        """Exécute une opération logique."""
