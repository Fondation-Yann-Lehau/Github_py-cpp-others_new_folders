    raw_result: bool
