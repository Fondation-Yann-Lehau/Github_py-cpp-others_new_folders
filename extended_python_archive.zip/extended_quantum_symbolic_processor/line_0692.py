        return {name: sensor.read() for name, sensor in self.sensors.items()}
