        print(f"  Transitions totales: {self.bridge.get_transition_count()}")
