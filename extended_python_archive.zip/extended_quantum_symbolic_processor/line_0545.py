        self.readings.append(value)
