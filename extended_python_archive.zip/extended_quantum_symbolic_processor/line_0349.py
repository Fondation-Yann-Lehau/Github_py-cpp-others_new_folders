        self.total_execution_time_ms = 0.0
