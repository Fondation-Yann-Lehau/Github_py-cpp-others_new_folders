            TransitionPhase.WAVE: "~ ~ ~ (Onde)",
