    def __init__(self, bridge: QuantumClassicalBridge, 
