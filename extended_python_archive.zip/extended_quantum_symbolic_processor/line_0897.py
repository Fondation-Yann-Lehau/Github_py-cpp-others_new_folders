        obs_summary = self.bridge.get_observations_summary()
