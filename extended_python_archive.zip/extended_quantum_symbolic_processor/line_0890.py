        # Statistiques du processeur logique
