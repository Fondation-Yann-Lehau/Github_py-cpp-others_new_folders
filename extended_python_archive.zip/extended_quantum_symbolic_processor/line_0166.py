        """Transforme inversement des données."""
