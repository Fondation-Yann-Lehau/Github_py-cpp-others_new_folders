    NOT = auto()    # Négation
