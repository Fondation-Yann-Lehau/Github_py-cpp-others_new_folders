        return final_state
