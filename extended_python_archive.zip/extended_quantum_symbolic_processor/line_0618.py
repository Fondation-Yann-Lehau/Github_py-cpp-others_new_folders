        self.retry_delay_ms = retry_delay_ms
