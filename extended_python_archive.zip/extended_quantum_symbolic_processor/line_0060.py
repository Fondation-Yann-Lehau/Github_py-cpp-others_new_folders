    """Modes de traitement du système."""
