        self.history.append(self.value)
