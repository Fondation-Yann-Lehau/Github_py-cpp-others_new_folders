    def _compute_operation(self, op: OperationType, inputs: List[bool]) -> bool:
