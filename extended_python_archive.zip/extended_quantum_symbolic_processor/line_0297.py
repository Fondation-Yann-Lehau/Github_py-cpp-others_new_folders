        Interprète un état potentiel en état classique déterminé.
