        print(f"Longueur transformée: {len(transformed)}")
