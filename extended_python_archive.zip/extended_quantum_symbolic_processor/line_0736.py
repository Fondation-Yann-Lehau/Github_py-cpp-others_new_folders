            NavigationDecision.STOP: (0, 0)
