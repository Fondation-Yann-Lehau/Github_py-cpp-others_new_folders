    def get_signature_hash(self, signature: Dict[str, float]) -> str:
