        self.run_logic_tests()
