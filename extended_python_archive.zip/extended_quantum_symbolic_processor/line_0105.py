    inputs: List[bool]
