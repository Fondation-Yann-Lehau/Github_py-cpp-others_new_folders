        self.transformer = ExponentialDataTransformer()
