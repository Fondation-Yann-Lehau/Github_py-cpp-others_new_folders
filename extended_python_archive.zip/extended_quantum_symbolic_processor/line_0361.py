        elif op == OperationType.XOR:
