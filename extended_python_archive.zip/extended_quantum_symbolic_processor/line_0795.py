        # Timestamp de démarrage
