        self.factors_map[name] = base_value
