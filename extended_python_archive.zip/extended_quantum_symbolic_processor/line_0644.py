        return self.error_count / total if total > 0 else 0
