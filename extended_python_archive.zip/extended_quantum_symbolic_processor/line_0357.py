        if op == OperationType.AND:
