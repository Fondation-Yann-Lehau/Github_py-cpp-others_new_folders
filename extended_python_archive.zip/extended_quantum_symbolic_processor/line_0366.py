            result = not all(inputs)
