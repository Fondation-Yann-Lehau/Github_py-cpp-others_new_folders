                # Les deux côtés libres - choisir le plus grand
