    def quantify(self, text_content: str = "") -> Dict[str, float]:
