        Applique une transformation exponentielle aux octets des données.
