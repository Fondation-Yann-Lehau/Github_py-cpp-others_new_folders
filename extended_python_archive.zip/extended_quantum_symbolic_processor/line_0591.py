        self.state_history.append((datetime.datetime.now(), self.current_state))
