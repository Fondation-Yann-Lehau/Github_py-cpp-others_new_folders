            result = not any(inputs)
