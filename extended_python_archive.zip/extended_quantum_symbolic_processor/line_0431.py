    """Transformateur de données utilisant des transformations exponentielles."""
