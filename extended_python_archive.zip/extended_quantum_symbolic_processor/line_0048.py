    NAND = auto()   # Non-conjonction
