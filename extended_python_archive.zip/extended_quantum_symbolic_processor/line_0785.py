        self.bridge = QuantumClassicalBridge(visualization=self.viz)
