    def get_average(self) -> float:
