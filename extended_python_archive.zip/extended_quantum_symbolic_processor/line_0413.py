        return [self.execute(op, inputs) for op, inputs in operations]
