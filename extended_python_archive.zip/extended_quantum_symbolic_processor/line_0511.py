        """Ajoute un facteur personnalisé."""
