        self.execute_movement(decision)
