        sys.stdout.write(" | Traitement: ")
