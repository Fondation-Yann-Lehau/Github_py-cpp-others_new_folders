    operation: OperationType
