class OperationType(Enum):
