    SYNCHRONOUS = auto()
