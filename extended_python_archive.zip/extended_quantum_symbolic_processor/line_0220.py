        sys.stdout.write("→ ")
