        """Calcule un hash de la signature."""
