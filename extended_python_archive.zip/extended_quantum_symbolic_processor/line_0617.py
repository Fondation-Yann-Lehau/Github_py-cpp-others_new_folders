        self.max_retries = max_retries
