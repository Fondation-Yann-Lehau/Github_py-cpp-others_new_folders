    def execute_movement(self, decision: NavigationDecision) -> None:
