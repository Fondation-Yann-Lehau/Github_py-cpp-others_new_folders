    XNOR = auto()   # Équivalence
