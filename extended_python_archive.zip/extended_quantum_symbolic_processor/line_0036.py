class BinaryState(Enum):
