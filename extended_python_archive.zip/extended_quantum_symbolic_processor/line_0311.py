        observation.phase = TransitionPhase.TRANSITION
