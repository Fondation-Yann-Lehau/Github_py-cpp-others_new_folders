                raise RuntimeError("Échec simulé")
