        print(f"Données d'entrée: {test_data[:50]}...")
