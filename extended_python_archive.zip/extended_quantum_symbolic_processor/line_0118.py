    average_transition_time_ms: float = 0.0
