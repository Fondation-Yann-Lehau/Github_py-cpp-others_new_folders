        if front_clear:
