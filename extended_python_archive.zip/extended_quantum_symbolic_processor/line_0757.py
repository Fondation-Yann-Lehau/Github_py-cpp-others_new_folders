    def get_navigation_log(self) -> List[NavigationDecision]:
