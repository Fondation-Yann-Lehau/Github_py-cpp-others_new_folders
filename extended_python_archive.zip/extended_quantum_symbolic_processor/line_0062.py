    ASYNCHRONOUS = auto()
