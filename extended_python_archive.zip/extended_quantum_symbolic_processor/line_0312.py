        self.visualize_transition(potential)
