            OperationType.XNOR: "⊙"
