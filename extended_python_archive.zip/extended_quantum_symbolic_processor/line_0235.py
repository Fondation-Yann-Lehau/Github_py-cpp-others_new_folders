            OperationType.AND: "∧",
