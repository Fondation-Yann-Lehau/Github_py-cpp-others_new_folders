        return self.computed_signatures.copy()
