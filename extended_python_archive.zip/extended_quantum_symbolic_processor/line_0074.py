    potential_state: bool
