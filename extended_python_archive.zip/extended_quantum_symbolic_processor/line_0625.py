        """Exécute une opération avec gestion de la résilience."""
