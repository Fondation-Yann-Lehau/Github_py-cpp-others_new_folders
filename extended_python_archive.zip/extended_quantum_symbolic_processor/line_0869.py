        # Test avec échecs
