        """Effectue n lectures."""
