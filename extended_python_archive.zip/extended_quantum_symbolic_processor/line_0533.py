        self.min_val = min_val
