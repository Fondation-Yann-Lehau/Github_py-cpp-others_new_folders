        self.viz = visualization or VisualizationEngine()
