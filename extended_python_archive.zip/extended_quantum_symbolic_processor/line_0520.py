    def get_all_signatures(self) -> List[Dict[str, float]]:
