            "ratio": ones / len(self.observations)
