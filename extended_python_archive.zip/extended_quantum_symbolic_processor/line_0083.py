        self.phase = TransitionPhase.FIXED
