                    decision = NavigationDecision.TURN_RIGHT
