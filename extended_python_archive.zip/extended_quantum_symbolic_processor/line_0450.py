                    transformed.append(float('inf'))
