            "count": len(self.readings),
