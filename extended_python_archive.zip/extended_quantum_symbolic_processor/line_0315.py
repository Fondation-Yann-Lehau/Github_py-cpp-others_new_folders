        final_state = observation.collapse()
