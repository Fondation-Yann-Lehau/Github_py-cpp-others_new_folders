    FIXED = auto()      # État binaire déterminé
