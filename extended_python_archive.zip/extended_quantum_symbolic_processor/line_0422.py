            "average_execution_time_ms": self.total_execution_time_ms / total_ops if total_ops > 0 else 0,
