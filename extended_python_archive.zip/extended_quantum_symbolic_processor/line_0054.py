    WAVE = auto()       # Onde - potentiel en mouvement
