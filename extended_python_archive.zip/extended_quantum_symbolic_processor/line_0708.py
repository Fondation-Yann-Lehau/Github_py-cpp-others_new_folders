            # Utilisation de XOR pour la décision de direction
