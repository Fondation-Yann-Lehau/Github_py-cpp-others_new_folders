        """Définit la graine pour la reproductibilité."""
