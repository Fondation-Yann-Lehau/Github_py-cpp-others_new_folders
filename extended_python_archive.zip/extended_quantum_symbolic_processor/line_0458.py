        """Tente de reconstruire les données originales."""
