        self.timestamp = datetime.datetime.now()
