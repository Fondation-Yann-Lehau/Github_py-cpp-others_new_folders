        # Phase 3: État fixé
