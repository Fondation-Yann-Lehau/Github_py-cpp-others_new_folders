class TransitionPhase(Enum):
