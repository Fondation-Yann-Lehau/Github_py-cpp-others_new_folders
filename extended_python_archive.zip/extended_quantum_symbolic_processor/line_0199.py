        final_state = state == BinaryState.ONE
