                context: str = "") -> OperationResult:
