        self.results_history.append(result)
