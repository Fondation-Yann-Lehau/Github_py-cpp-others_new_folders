                if val == float('inf') or val <= 0:
