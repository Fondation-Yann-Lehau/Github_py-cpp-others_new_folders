    """Types d'opérations logiques supportées."""
