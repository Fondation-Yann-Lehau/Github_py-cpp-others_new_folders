        sys.stdout.write(self.animation_frames[TransitionPhase.TRANSITION] + " ")
