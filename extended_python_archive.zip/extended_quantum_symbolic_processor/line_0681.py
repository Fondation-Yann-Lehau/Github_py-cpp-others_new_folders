            "right": SensorSimulator("right_distance")
