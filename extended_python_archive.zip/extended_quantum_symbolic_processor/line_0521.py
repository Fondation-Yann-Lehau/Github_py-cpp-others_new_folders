        """Retourne toutes les signatures calculées."""
