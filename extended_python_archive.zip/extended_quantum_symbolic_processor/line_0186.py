    def set_enabled(self, enabled: bool) -> None:
