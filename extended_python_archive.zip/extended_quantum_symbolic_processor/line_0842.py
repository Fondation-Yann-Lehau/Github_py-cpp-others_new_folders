        for key, value in factors.items():
