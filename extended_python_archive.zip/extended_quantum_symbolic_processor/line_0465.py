                    byte_val = int(math.log(val) * 100 / self.security_coefficient)
