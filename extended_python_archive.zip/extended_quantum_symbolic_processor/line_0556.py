    def get_statistics(self) -> Dict[str, float]:
