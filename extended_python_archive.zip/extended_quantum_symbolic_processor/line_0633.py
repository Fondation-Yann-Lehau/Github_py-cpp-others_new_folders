                self.error_log.append((datetime.datetime.now(), str(e)))
