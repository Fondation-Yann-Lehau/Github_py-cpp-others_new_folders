    def read_all_sensors(self) -> Dict[str, float]:
