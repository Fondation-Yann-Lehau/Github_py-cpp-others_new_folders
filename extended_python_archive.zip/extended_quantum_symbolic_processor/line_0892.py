        print(f"\n[Processeur Logique]")
