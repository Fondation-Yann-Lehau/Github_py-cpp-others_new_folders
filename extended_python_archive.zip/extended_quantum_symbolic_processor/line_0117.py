    total_transitions: int = 0
