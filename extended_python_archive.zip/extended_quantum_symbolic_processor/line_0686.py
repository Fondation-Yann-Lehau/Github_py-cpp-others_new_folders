            "left_motor": ActuatorSimulator("left_motor"),
