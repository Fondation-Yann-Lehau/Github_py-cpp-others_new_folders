    def execute_batch(self, operations: List[Tuple[OperationType, List[bool]]]) -> List[OperationResult]:
