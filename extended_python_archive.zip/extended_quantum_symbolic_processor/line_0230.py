        """Visualise le résultat d'une opération logique."""
