Paradigme: États binaires comme transitions cycloidales
