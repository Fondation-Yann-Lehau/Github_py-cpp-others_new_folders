        print(f"  [{op.name} ({symbol})] Résultat: {1 if result else 0}")
