              f"L:{readings['left']:.1f} R:{readings['right']:.1f}")
