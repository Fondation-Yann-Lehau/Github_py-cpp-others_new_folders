            self.navigation.run_cycle()
