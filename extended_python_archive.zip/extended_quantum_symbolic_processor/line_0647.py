        """Retourne les statistiques de résilience."""
