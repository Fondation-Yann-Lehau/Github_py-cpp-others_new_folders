        elif op == OperationType.XNOR:
