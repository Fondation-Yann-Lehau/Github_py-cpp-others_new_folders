    print("\n" + "#" * 70)
