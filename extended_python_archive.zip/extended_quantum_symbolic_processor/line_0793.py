        self.bridge.describe_paradigm()
