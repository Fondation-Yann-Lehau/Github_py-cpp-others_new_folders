        print(f"  Temps d'exécution total: {logic_stats['total_execution_time_ms']:.2f} ms")
