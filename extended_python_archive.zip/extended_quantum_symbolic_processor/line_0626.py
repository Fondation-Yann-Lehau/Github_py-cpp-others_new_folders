        retries = max_retries or self.max_retries
