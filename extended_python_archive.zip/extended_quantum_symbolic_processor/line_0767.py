    Système unifié intégrant tous les composants:
