            decision = NavigationDecision.FORWARD
