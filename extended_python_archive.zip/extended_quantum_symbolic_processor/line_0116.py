    failed_operations: int = 0
