        frame_func = self.animation_frames[TransitionPhase.FIXED]
