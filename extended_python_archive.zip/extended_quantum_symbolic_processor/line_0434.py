        self.security_coefficient = security_coefficient
