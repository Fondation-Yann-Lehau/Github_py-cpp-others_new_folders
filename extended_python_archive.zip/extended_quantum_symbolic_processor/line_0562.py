        variance = sum((x - avg) ** 2 for x in self.readings) / len(self.readings)
