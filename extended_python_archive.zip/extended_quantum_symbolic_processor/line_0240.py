            OperationType.NOR: "⊽",
