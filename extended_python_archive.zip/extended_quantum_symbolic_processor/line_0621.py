        self.error_log: List[Tuple[datetime.datetime, str]] = []
