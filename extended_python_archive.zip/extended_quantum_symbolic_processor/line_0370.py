            result = sum(inputs) % 2 == 0
