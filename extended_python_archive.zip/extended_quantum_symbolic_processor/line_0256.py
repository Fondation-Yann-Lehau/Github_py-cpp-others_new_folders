            normalized = int(20 * abs(val) / max_val) if max_val > 0 else 0
