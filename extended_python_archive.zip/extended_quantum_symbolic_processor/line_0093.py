    history: List[bool] = field(default_factory=list)
