    STREAMING = auto()
