            OperationType.OR: "∨",
