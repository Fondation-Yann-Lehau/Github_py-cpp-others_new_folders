                    bytes_list.append(0)
