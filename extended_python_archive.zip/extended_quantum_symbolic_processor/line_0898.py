        print(f"\n[Pont Quantique-Classique]")
