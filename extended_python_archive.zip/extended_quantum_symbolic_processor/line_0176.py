    def __init__(self, delay_ms: int = 150, enabled: bool = True):
