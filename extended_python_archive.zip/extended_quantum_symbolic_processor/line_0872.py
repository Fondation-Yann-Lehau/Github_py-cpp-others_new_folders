            fail_counter[0] += 1
