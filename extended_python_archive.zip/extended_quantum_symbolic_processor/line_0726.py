        self.navigation_log.append(decision)
