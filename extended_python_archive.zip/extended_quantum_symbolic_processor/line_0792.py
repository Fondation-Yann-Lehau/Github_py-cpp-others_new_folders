        # Description du paradigme
