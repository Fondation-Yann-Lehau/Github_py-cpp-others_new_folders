    def interpret_state(self, potential: bool, context: str) -> bool:
