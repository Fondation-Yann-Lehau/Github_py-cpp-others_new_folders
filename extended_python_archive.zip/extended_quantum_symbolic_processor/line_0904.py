        res_stats = self.resilience.get_statistics()
