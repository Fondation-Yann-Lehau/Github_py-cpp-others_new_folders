        self._paradigm_description = """
