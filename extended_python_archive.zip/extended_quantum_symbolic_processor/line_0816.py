        for op, inputs in tests:
