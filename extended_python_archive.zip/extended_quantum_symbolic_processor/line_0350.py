        self.results_history: List[OperationResult] = []
