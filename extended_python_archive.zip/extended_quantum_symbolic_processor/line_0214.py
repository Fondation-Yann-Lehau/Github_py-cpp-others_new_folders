        # Phase 2: Transition
