        """Incrémente l'état."""
