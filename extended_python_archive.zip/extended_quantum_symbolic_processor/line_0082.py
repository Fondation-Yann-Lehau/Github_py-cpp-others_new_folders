        self.observed_state = self.potential_state
