        result = self.resilience.execute_with_resilience(
