        self.observations.append(observation)
