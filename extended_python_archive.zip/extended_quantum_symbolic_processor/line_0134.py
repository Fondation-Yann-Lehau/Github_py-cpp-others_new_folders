    def visualize_transition(self, state: bool) -> None:
