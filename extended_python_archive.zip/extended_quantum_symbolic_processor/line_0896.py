        # Statistiques du pont quantique
