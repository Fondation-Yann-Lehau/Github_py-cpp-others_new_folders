            (OperationType.XOR, [True, False]),
