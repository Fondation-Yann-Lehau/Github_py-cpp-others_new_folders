    def __init__(self, security_coefficient: float = 0.873):
