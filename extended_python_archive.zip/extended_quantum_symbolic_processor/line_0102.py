class OperationResult:
