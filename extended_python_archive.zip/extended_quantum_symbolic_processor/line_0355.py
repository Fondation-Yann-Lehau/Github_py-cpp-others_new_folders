            raise ValueError("Aucune entrée fournie")
