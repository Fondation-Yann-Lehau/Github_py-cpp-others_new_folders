        elif op == OperationType.OR:
