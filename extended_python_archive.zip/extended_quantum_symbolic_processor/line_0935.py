    print("#" * 70 + "\n")
