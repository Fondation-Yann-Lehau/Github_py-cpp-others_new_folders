        """Exécute une simulation de navigation."""
