    system = UnifiedQuantumSymbolicSystem(animation_delay_ms=100)
