    def get_observations_summary(self) -> Dict[str, Any]:
