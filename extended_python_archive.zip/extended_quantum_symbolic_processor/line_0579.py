    def __init__(self, name: str, min_state: float = 0, max_state: float = 100):
