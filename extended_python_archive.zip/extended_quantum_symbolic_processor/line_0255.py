        for i, val in enumerate(data[:10]):  # Limité à 10 valeurs
