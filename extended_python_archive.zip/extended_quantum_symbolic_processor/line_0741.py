        self.actuators["right_motor"].set_state(right_power)
