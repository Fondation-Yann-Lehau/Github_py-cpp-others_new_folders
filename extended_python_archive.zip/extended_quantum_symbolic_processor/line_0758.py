        """Retourne le log de navigation."""
