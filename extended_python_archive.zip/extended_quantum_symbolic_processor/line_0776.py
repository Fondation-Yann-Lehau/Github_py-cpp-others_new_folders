    def __init__(self, animation_delay_ms: int = 150):
