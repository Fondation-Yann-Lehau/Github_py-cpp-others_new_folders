            print(f"Erreur de transformation inverse: {e}")
