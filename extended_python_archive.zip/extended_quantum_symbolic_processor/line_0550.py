        return [self.read() for _ in range(n)]
