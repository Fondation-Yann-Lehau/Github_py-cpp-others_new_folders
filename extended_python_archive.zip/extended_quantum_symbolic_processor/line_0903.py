        # Statistiques de résilience
