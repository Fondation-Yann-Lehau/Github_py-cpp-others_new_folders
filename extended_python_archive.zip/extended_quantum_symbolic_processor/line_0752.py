        decision = self.evaluate_path(readings)
