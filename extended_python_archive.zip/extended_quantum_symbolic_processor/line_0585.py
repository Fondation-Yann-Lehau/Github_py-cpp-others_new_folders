        self.state_history: List[Tuple[datetime.datetime, float]] = []
