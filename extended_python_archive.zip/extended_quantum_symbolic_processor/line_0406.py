        self.operation_counts[operation] += 1
