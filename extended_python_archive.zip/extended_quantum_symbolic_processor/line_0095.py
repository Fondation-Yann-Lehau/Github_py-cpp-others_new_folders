    def update(self, new_value: bool) -> None:
