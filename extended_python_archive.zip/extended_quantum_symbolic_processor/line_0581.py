        self.min_state = min_state
