    def execute(self, operation: OperationType, inputs: List[bool]) -> OperationResult:
