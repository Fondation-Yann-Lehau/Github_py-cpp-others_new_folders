        print("[RÉSILIENCE] Utilisation de la valeur de fallback")
