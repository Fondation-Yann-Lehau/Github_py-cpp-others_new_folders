class SignalData:
