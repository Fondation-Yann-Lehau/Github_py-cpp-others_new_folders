        """Réinitialise l'actionneur."""
