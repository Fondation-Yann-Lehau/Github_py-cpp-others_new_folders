class IDataTransformer(ABC):
