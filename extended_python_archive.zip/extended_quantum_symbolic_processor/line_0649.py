            "error_count": self.error_count,
