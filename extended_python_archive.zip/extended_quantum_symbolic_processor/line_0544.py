        value = self._random.uniform(self.min_val, self.max_val)
