    def print_system_report(self) -> None:
