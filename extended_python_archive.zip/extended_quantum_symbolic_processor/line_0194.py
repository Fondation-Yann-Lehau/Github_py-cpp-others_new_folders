    def visualize_collapse(self, state: BinaryState) -> None:
