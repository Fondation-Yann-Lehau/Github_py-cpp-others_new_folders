    XOR = auto()    # Annulation / Différence
