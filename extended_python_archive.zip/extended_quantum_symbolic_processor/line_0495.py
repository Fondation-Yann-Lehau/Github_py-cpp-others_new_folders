            'coherence': 2.718281828,      # e
