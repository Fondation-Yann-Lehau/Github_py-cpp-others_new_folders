class ProcessingMode(Enum):
