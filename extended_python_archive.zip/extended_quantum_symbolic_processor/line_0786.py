        self.logic = LogicProcessor(bridge=self.bridge, visualization=self.viz)
