        return self.state_history.copy()
